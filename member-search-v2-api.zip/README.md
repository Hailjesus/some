 
1. <B>Title:</B> member-search-v2-api

2. <B>Description:</B> This API serves the purpose of retrieving the member search information by using members operation where all the operationId interacts with mbr_coverage schema in DDS by using criteria as its query and also uses like any one mandatory parameters like memberLifeId,subscriberId,memberSSN, sourceSystemMemberIdFilter, firstName & LastName, firstName & DOB and lastName & DOB to get the Members information. 

      members : This endpoint operation is used to retrieve the list of members that matches the specific criteria.To serve this request mandatory and optional parameters values must be provided.The accountId define the list group association related to account which get from member-group-api which the specific groupid and its groupAssociationStartDate and groupAssociationStartDate to filter out coverage DDS members groupId with enrollmenteffective Date and termination Date.
      
3. <B>Documentation:</B> <br>
	a.	OpenAPI Definitions:<br>
        	<a href="https://nexus-deva.carefirst.com/member-search-v2-api/swagger-ui/index.html">Swagger UI</a>
         <br>
       		 <a href="https://dev.azure.com/CareFirstCloud/nexus-member-coverage/_git/member-search-v2-api?path=/src/main/resources/yaml/member-search-v2-api.yaml&version=GBdevelop&_a=contents"> Microservice Spec </a>  <br> <a href="https://nexus-deva.carefirst.com/member-search-v2-api/actuator/health"> Health check URL </a><br>
       	
   	
      b.	Features: Member Search V2 Details retrieving by interacting with coverage DDS <br>

	c.	Backing systems
	
		1. DDS
                DEVA:
                schema: mbr_coverage
                spring.datasource.url=jdbc:postgresql://psql-nexusmembcovdeva-dev-001.postgres.database.azure.com:5432/membcoveragedeva
                SITA:
                schema: mbr_coverage
                spring.datasource.url=jdbc:postgresql://psql-nexusmembcovsita-test-001.postgres.database.azure.com:5432/membcoveragesita
                PIT:
                schema: mbr_coverage
                spring.datasource.url=jdbc:postgresql://psql-nexmembcovpit-test-001.postgres.database.azure.com:5432/membcoveragepit
                UAT:
                schema: mbr_coverage
                spring.datasource.url=jdbc:postgresql://psql-nexmembcovuat-uat-001.postgres.database.azure.com:5432/membcoverageuat
	
	
4.  <B>Setup and Configuration:</B> SpringBoot Maven Project with all dependencies added in Nexus parent Project.
       
5. <B>Solution Manager: </B> Gupta, Rajan Rajan.Gupta@carefirst.com

6. <B>System Architect: </B> Deshpande, Shamkant Shamkant.Deshpande@carefirst.com, Mahadevappa, Chethan <Chethan.Mahadevappa@carefirst.com>

7. <B>Domain SME: </B> Kumar, Sumit Sumit.Kumar@carefirst.com

8. <B>Developer Lead: </B> Thumma, Ayyappa Ayyappa.Thumma@carefirst.com

9. <B> Supporting DL:  </B> Nexus Domain Team 2 NexusDomainTeam2@carefirst.com
