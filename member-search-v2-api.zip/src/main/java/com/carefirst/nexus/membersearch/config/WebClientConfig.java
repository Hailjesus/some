package com.carefirst.nexus.membersearch.config;

import java.text.DateFormat;
import java.time.Duration;
import java.util.TimeZone;

import org.openapitools.RFC3339DateFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import com.carefirst.nexus.fepmembercoverage.gen.api.FepmemberCoverageApi;
import com.carefirst.nexus.fepmembercoverage.gen.invoker.ApiClient;
import com.carefirst.nexus.group.gen.api.GroupAccountDetailsApi;
import com.carefirst.nexus.group.gen.api.GroupDetailsApi;
import com.carefirst.nexus.utils.web.config.rest.WebUtilsFilter;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.netty.http.client.HttpClient;

@Configuration
public class WebClientConfig {
	@Value("${application.client.search.v1.readTimeOut}")
	private int readTimeOut;

	@Value("${application.endpoint.fepmemberCoverageApiURL}")
	private String fepmemberCoverageApiBasepath;

	@Value("${application.endpoint.groupServiceURL}")
	private String groupServiceApipath;

	@Value("${oauth2.client.registrationId}")
	private String registrationId;

	private ObjectMapper objectMapper;
	
	OAuth2AuthorizedClientManager authorizedClientManager;

	public WebClientConfig(OAuth2AuthorizedClientManager authorizedClientManager){
		this.authorizedClientManager = authorizedClientManager;
	}
	WebUtilsFilter webUtil = new WebUtilsFilter(authorizedClientManager,registrationId);

	
	@Bean
	WebClient webClient(OAuth2AuthorizedClientManager authorizedClientManager) {
		ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client = new ServletOAuth2AuthorizedClientExchangeFilterFunction(
				authorizedClientManager);
		oauth2Client.setDefaultClientRegistrationId(registrationId);
		HttpClient httpClient = HttpClient.create().responseTimeout(Duration.ofMillis(60000));
		return WebClient.builder().filter(webUtil.guidFilter()).filter(webUtil.authTokenFilter())
				.clientConnector(new ReactorClientHttpConnector(httpClient))
				.exchangeStrategies(ExchangeStrategies.builder()
						.codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024)).build())
				.build();
	}

	public DateFormat createDefaultDateFormat() {
		DateFormat dateFormat = new RFC3339DateFormat();
		dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
		return dateFormat;
	}

	@Bean
	public FepmemberCoverageApi fepmemberCoverageApi(WebClient webClient) {
		ApiClient apiClient = new ApiClient(webClient, objectMapper, createDefaultDateFormat());
		apiClient.setBasePath(fepmemberCoverageApiBasepath);
		return new FepmemberCoverageApi(apiClient);
	}

	@Bean
	public GroupAccountDetailsApi groupAccountDetailApi(WebClient webClient) {
		com.carefirst.nexus.group.gen.invoker.ApiClient apiClient = new com.carefirst.nexus.group.gen.invoker.ApiClient(webClient, objectMapper, createDefaultDateFormat());
		apiClient.setBasePath(groupServiceApipath);
		return new GroupAccountDetailsApi(apiClient);
	}
	
	@Bean
	public GroupDetailsApi groupDetailsApi(WebClient webClient) {
		com.carefirst.nexus.group.gen.invoker.ApiClient apiClient = new com.carefirst.nexus.group.gen.invoker.ApiClient(webClient, objectMapper, createDefaultDateFormat());
		apiClient.setBasePath(groupServiceApipath);
		return new GroupDetailsApi(apiClient);
	}
}