package com.carefirst.nexus.membersearch.model;

import java.time.LocalDate;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import java.util.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author carefirst
 *         This is a sample implementation of Entity class. Please delete this
 *         file or modify your entity classes as shown in the example below.
 * 
 *         Use Lomboks @Data annotation: This
 *         combines @Getter, @Setter, @ToString, @EqualsAndHashCode,
 *         and @RequiredArgsConstructor into a single annotation.
 *         Use @Builder for the Builder pattern: This makes it easier to create
 *         instances of the class.
 *         Use @AllArgsConstructor and @NoArgsConstructor: These annotations
 *         generate constructors with and without parameters.
 **/

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSearchV2ApiModel {

    private String memberLifeId;
    private String memberSSN;
    private String subscriberId;
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private Gender gender;
    private RelationshipToSubscriber relationshipToSubscriber;
    private String city;
    private String state;
    private String zipCode;
    private String primaryEmailAddress;
    private String primaryPhoneNumber;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<String> groupIds;
    private List<GroupFilter> groupFilter;
    private String accountId;
    private List<ProductCategory> productCategories;
    private List<EnrollmentSystemCode> enrollmentSystemCodes;
    private List<SourceSystemMemberIdFilter> sourceSystemMemberIdFilter;
    private List<MemberSuffixFilter> memberSuffixFilter;
    private Boolean expandSearchWithMemberLifeId;
    private Boolean exactMatchOnName;
    private List<ClaimsSystemCode> claimsSystemCodes;
    private List<String> subGroupIds;
    private Boolean extendSubgroupIdsMatchToDeptNumber;
    private Boolean partialMatchMemberSSNEndsWith;
    private Boolean useFemsForFep;

}
