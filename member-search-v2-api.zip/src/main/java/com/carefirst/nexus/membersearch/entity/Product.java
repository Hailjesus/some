
package com.carefirst.nexus.membersearch.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@Getter
@Setter
public class Product {

    private String category;
    private String productCode;
    private String description;
    private String planCode;
    private String productNameCode;
    private String benefitId;
    private String hmoPPOInd;
    private Boolean stckdInd;
    private Boolean cdhInd;
    @Valid
    private List<String> cplCode = null;
    private String riskCode;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate subGroupProductEffectiveDate;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate subGroupProductTerminationDate;
    private Boolean grndfthrInd;
    private String bsbsCode;
    private Boolean blueFundInd;
    private String blueFundDescription;
    private String cdhAdminCode;
    private String cdhFundingCode;
    private String metalCode;
    
    //Derived Attributes in Kafka
    private String dvbProductCategory;
    private Boolean silverScript;
    private Boolean branded;
    @Valid
    private CdhInfo cdhInfo;
    private String jurisdiction;
    private String legalEntity;
    private Boolean personalComp;
    private Boolean medsupDental;
    private Boolean medsupMedical;
    private Boolean medsupVision;
   
    private Boolean medicarePrimary;
    private Boolean mentalHealthParity;
    private Boolean over65;
    private Boolean vaes;
    
    /** Real Time Derived*/
    private Boolean aca;
    private String acaMetalevel;
    private String legacyProductDescription;
    private String productVariation;
    private String productVariationCategory;
    private String productVariationDescription;
    private String insuranceType;
    private Boolean pcpProduct;
    
    
	/*@Override
	public String toString() {
		return "Product [dvbProductCategory=" + dvbProductCategory + ", silverScript=" + silverScript + ", branded="
				+ branded + ", cdhInfo=" + cdhInfo + ", jurisdiction=" + jurisdiction + ", legalEntity=" + legalEntity
				+ ", personalComp=" + personalComp + ", medsupDental=" + medsupDental + ", medsupMedical="
				+ medsupMedical + ", medsupVision=" + medsupVision + ", medicarePrimary=" + medicarePrimary
				+ ", mentalHealthParity=" + mentalHealthParity + ", over65=" + over65 + ", vaes=" + vaes + "]";
	}*/
  
   
   
}
