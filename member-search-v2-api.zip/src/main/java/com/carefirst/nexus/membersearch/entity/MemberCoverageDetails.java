package com.carefirst.nexus.membersearch.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@Getter
@Setter
public class MemberCoverageDetails {

	private String sourceSystem;
    private String alternateId;
    private String legacyId;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate dateOfBirth;
    @Valid
    private Name name;
    private String gender;
    private String memberLifeId;
    private String memberSSN;
    private String memberSuffix;
    private String relationshipToSubscriber;
    
    private String publicSubscriberIdPrefix;
    private String publicSubscriberId;
    private String publicSubscriberIdType;
    private String subscriberEmployerId;
    @Valid
    private List<MemberCoverage> memberCoverages = null;
    
    /** Real Time Derived*/
    private String protectedGroupType;
    private String controlPlanCode;
    private String submitToPlanCode;
    
    private Boolean realTimeSrcFeed;
    
    
	/*@Override
	public String toString() {
		return "MemberCoverageDetails [accountId=" + accountId + ", accountName=" + accountName
				+ ", publicSubscriberIdPrefix=" + publicSubscriberIdPrefix + ", publicSubscriberId="
				+ publicSubscriberId + ", publicSubscriberIdType=" + publicSubscriberIdType + ", subscriberEmployerId="
				+ subscriberEmployerId + ", memberCoverages=" + memberCoverages + "]";
	}*/
   
   
  

}

