package com.carefirst.nexus.membersearch.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.fepmembercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberEnrollmentDetails;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberDescriptor;
import com.carefirst.nexus.membersearch.gen.model.Name;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FEPMemberHelper {
	
	private FEPMemberHelper(){}
	
	/**
	 * filterFEPMembers.
	 * @param ddsMembersList
	 * @return
	 */
	public static List<Member> filterFEPMembers(List<Member> ddsMembersList){
		log.debug(">< filterFEPMembers");
		return ddsMembersList.stream()
				.filter(m -> (null != m.getClaimsSystemCode()) && ClaimsSystemCode.FEP.equals(m.getClaimsSystemCode()))
				.toList();
	}
	
	public static List<Member> filterNonFEPMembers(List<Member> ddsMembersList){
		log.debug(">< filterNonFEPMembers");
		return ddsMembersList.stream()
				.filter(m -> (null == m.getClaimsSystemCode()) || !ClaimsSystemCode.FEP.equals(m.getClaimsSystemCode()))
				.toList();
	}
	
	/**
	 * extractSubscriberId.
	 * @param subscriberId
	 * @param memberLifeId
	 * @return
	 */
	public static String extractSubscriberId(String subscriberId, String memberLifeId) {
		log.debug("> extractSubscriberId");
		String subId = null;
		 if(StringUtils.hasText(subscriberId) && subscriberId.startsWith("R") && subscriberId.length() == 9 && subscriberId.substring(1).matches("\\d{8}")){
			 subId = subscriberId;
		 }
		 if(!StringUtils.hasText(subId) && StringUtils.hasText(memberLifeId) && (memberLifeId.startsWith("T060") || memberLifeId.startsWith("T064"))){
			 subId = memberLifeId.substring(4,13); //will take suffix out, T060R1234567801 to R12345678
		 }
		 log.debug("< extractSubscriberId");
		return subId;
	}
	
	/**
	 * @param fepMembers
	 * @return
	 */
	public static List<String> getDistinctSubscriberIdSuffix(List<Member> fepMembers) {
		log.debug(">< getDistinctSubscriberId");
		return fepMembers.stream().filter(m -> null != m.getMemberDescriptor())
				.map(m -> m.getMemberDescriptor().getSubscriberId() + "_" + (null != m.getMemberDescriptor().getMemberSuffix() ? m.getMemberDescriptor().getMemberSuffix() : ""))
				.distinct().toList();
	}
	
	/**
	 * Null check element list and add to final list.
	 * @param finalList
	 * @param elements
	 * @return
	 */
	public static <T> List<T> addAll(List<T> finalList, List<T> elements) {
		log.debug("> addAll");
		if(null != elements && !CollectionUtils.isEmpty(elements)){
			finalList.addAll(elements);
		}
		log.debug("< addAll");
		return finalList;
	}


	/**
	 * transformCoverageTypeToMemberSearchList.
	 * @param fepCoveragesList
	 * @return
	 */
	public static List<Member> transformCoverageTypeToMemberSearchList(List<MemberCoverage> fepCoveragesList) {
		log.debug("> transformCoverageTypeToMemberSearchList");
		List<Member> members = new ArrayList<>();
		if(!CollectionUtils.isEmpty(fepCoveragesList)){
			log.info("findFepMemberCoverages response size:: {} ", fepCoveragesList.size());

			for (MemberCoverage memberCoverage : fepCoveragesList) {
				Member member = new Member();
				MemberDescriptor memberDescriptor = new MemberDescriptor();
				com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor covMemberDescriptor = memberCoverage.getMemberDescriptor();
				memberDescriptor.setSourceSystemMemberId(covMemberDescriptor.getSourceSystemMemberId());
				memberDescriptor.setEnrollmentSystemCode(mapEnrollmentSystemCode(covMemberDescriptor.getEnrollmentSystemCode()));
				memberDescriptor.setSubscriberId(covMemberDescriptor.getSubscriberId());
				memberDescriptor.setAlternateId(covMemberDescriptor.getAlternateId());
				memberDescriptor.setLegacyId(covMemberDescriptor.getLegacyId());
				memberDescriptor.setDateofBirth(covMemberDescriptor.getDateofBirth());
				
				memberDescriptor.setName(mapName(covMemberDescriptor));
				
				memberDescriptor.setGender(mapGender(covMemberDescriptor.getGender()));
				memberDescriptor.setRelationshipToSubscriber(mapRelationshipToSubscriber(covMemberDescriptor.getRelationshipToSubscriber()));
				memberDescriptor.setMemberLifeId(covMemberDescriptor.getMemberLifeId());
				memberDescriptor.setMemberSSN(covMemberDescriptor.getMemberSSN());
				memberDescriptor.setMemberSuffix(covMemberDescriptor.getMemberSuffix());
				memberDescriptor.setGroupId(covMemberDescriptor.getGroupId());
				memberDescriptor.setProtectedGroupType(covMemberDescriptor.getProtectedGroupType());
				memberDescriptor.setPublicSubscriberIdPrefix(covMemberDescriptor.getPublicSubscriberIdPrefix());
				memberDescriptor.setPublicSubscriberId(covMemberDescriptor.getPublicSubscriberId());
				memberDescriptor.setPublicSubscriberIdType(covMemberDescriptor.getPublicSubscriberIdType());
				memberDescriptor.setSubscriberEmployerId(covMemberDescriptor.getSubscriberEmployerId());
				member.setMemberDescriptor(memberDescriptor);
				

				MemberEnrollmentDetails memberEnrollmentDetails = memberCoverage.getMemberEnrollmentDetails();
				
				if (null != memberEnrollmentDetails) {
					member.setClaimsSystemCode(mapClaimsSystemCode(memberEnrollmentDetails.getClaimsSystemCode()));
					if (null != memberEnrollmentDetails.getCoverageStatus()) {
						member.setEffectiveDate(memberEnrollmentDetails.getCoverageStatus().getEffectiveDate());
						member.setTerminationDate(memberEnrollmentDetails.getCoverageStatus().getTerminationDate());
					}
					if (null != memberEnrollmentDetails.getProduct()
							&& !CollectionUtils.isEmpty(memberEnrollmentDetails.getProduct())
							&& null != memberEnrollmentDetails.getProduct().get(0)) {
						
						member.setProductCategory(mapProductCategory(memberEnrollmentDetails.getProductCategory())); 
						member.setProductId(memberEnrollmentDetails.getProduct().get(0).getProductCode());
					}
				}
				member.setSubGroupId(covMemberDescriptor.getSubgroupId());
				members.add(member);
			}
		}
		log.debug("< transformCoverageTypeToMemberSearchList");
		return members;
	}

	private static Name mapName(com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor covMemberDescriptor) {
		Name name = new Name();
		if (null != covMemberDescriptor.getName()) {
			name.setFirstName(covMemberDescriptor.getName().getFirstName());
			name.setLastName(covMemberDescriptor.getName().getLastName());
			name.setMiddleName(covMemberDescriptor.getName().getMiddleName());
			name.setPrefix(covMemberDescriptor.getName().getPrefix());
			name.setSuffix(covMemberDescriptor.getName().getSuffix());
		}
		return name;
	}

	private static ProductCategory mapProductCategory(
			com.carefirst.nexus.fepmembercoverage.gen.model.ProductCategory fepProductCategory) {
		return null != fepProductCategory ? ProductCategory.fromValue(fepProductCategory.toString()) : null;
	}

	private static ClaimsSystemCode mapClaimsSystemCode(
			com.carefirst.nexus.fepmembercoverage.gen.model.ClaimsSystemCode fepClaimsSystemCode) {
		return null != fepClaimsSystemCode ? ClaimsSystemCode.fromValue(fepClaimsSystemCode.toString()) : null;
	}

	private static Gender mapGender(com.carefirst.nexus.fepmembercoverage.gen.model.Gender fepGender) {
		return null != fepGender ? Gender.fromValue(fepGender.toString()) : null;
	}

	private static RelationshipToSubscriber mapRelationshipToSubscriber(
			com.carefirst.nexus.fepmembercoverage.gen.model.RelationshipToSubscriber fepRelationshipToSubscriber) {
		return null != fepRelationshipToSubscriber
				? RelationshipToSubscriber.fromValue(fepRelationshipToSubscriber.toString()) : null;
	}

	private static EnrollmentSystemCode mapEnrollmentSystemCode(
			com.carefirst.nexus.fepmembercoverage.gen.model.EnrollmentSystemCode fepEmrollmentSystemCode) {
		return null != fepEmrollmentSystemCode ? EnrollmentSystemCode.fromValue(fepEmrollmentSystemCode.toString())
				: null;
	}

}
