package com.carefirst.nexus.membersearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author carefirst
 *
 */
@SpringBootApplication
@ComponentScan({"com.carefirst.nexus.membersearch",
	"com.carefirst.nexus.utils.web.controllers.admin",
	"com.carefirst.nexus.datadict",
	"com.carefirst.nexus.utils.web.error",
	"com.carefirst.nexus.utils.web.config.rest",
	"com.carefirst.nexus.utils.web.config.token",
	"com.carefirst.nexus.gen"})
@RestController
public class  MemberSearchV2ApiApplication {
	public static void main(String[] args) {
		SpringApplication.run(MemberSearchV2ApiApplication.class, args);
	}
}
