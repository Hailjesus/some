package com.carefirst.nexus.membersearch.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.datadict.impl.DataDictionaryServiceImpl;
import com.carefirst.nexus.group.gen.api.GroupAccountDetailsApi;
import com.carefirst.nexus.group.gen.model.GroupAccount;
import com.carefirst.nexus.group.gen.model.GroupAccountSearchResponse;
import com.carefirst.nexus.membersearch.model.ProtectGroupTypeDataResponse;
import com.carefirst.nexus.utils.DateUtils;
import com.github.jknack.handlebars.internal.lang3.ObjectUtils;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class MemberDerivedDataService {


	private GroupAccountDetailsApi groupAccountDetailsApi;
	private DataDictionaryServiceImpl dataDictionaryService;

	public MemberDerivedDataService(GroupAccountDetailsApi groupAccountDetailsApi,
			DataDictionaryServiceImpl dataDictionaryService) {
		this.groupAccountDetailsApi = groupAccountDetailsApi;
		this.dataDictionaryService = dataDictionaryService;
	}

	/**
	 * fetchProtectedGroupType.
	 * 
	 * replaceFirst("^0+(?!$)", "") strips off leading zero's.
	 * 
	 * @param groupId
	 * @return
	 */
	public String fetchProtectedGroupType(final String groupId) {
		log.debug("> fetchProtectedGroupType");
		String protectedGrpTyp = "NOT_AVAILABLE";
		if (StringUtils.isNotBlank(groupId)) {
			String grpForPGCheck = StringUtils.stripStart(groupId, "0");
			if (grpForPGCheck.length() > 9) {
				grpForPGCheck = grpForPGCheck.substring(0, 9);
			}
			protectedGrpTyp = dataDictionaryService.getSingleMappedValue("CAREFIRST", "PROTECTED_GROUP", "CAREFIRST",
					"PROTECTED_GROUP_TYPE", grpForPGCheck, DateUtils.getCurrentDate());
		}
		log.debug("ProtectedGroupType : {}", protectedGrpTyp);
		log.debug("< fetchProtectedGroupType");
		return protectedGrpTyp;
	}

    /**
	 * This method is to get protectedGroupType from dataDictionaryService.
	 * 
     * @param memAccountDDSet
     * @return
     */
    public List<ProtectGroupTypeDataResponse> fetchProtectedGroupTypeDetails(
            Set<String> memAccountDDSet) {
		log.debug("> fetchProtectedGroupTypeDetails");
		List<ProtectGroupTypeDataResponse> result= new ArrayList<>();
		memAccountDDSet.stream().filter(ObjectUtils::isNotEmpty)
		.forEach(madddreq->{
			ProtectGroupTypeDataResponse maddres = new ProtectGroupTypeDataResponse();
			maddres.setGroupId(madddreq);
			maddres.setProtectedGroupType(fetchProtectedGroupType(madddreq));
			result.add(maddres);
		});
		return result;
    }


	/**
	 * This method is to fetch GroupIds from Accounts.
	 * 
	 * @param accountId
	 * @return
	 */
	public List<GroupAccount> fetchGroupAccountDetails(String accountId) {
		GroupAccountSearchResponse groupAccountSearchResponse = null;
		List<GroupAccount> groupsAccounts= new ArrayList<>();
		try {
			Mono<GroupAccountSearchResponse> response = groupAccountDetailsApi
					.getAccounts(null, null, Collections.singletonList(accountId), null, null, null);
			if(response!=null ){
				groupAccountSearchResponse = response.block();
			}
			if(groupAccountSearchResponse!=null){
				groupsAccounts = groupAccountSearchResponse.getAccounts();
			}
		} catch (Exception e) {
			log.error("No account details found", e);
			log.error(">>> No Account Information found for accountId {} from the GroupService call. <<<", accountId);
		}
		return groupsAccounts;
	}

}
