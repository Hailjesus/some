package com.carefirst.nexus.membersearch.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.carefirst.nexus.membersearch.constants.ApplicationConstants;
import com.carefirst.nexus.membersearch.entity.MemberCoverageEntity;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.membersearch.model.MemberSearchV2ApiModel;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Repository
public class MemberCoverageEntityManager {
    @PersistenceContext
    EntityManager entityManager;

    // Get Member Coverage Entities using Native Query on DDS.
    public List<MemberCoverageEntity> getMemberCoverageEntities(MemberSearchV2ApiModel memberSearchRequest) {

        String baseQuery = "select memb_cov_id,aud_insrt_id,aud_insrt_tmstp,aud_updt_id,aud_updt_tmstp,srce_sys_cd,group_id,cov_json,srce_sys_memb_id,sub_grp_id,subscriber_id, srce_sys_vald_thru_tmstp from mbr_coverage.memb_cov where 1=1";
        HashMap<String, Object> parameters = new HashMap<>();

        baseQuery = checkAndMapMemberLifeIdAndLastName(baseQuery,parameters,memberSearchRequest.getMemberLifeId(),memberSearchRequest.getLastName(),memberSearchRequest.getExactMatchOnName());
                
        baseQuery = checkAndMapMemberSSNSubscriberId(baseQuery,parameters,memberSearchRequest.getMemberSSN(),memberSearchRequest.getPartialMatchMemberSSNEndsWith(),
                memberSearchRequest.getSubscriberId());
        baseQuery = checkAndMapFirstNameAndDateOfBirthAndGender(baseQuery,parameters,memberSearchRequest.getFirstName(),memberSearchRequest.getExactMatchOnName(),memberSearchRequest.getDateOfBirth(),
                memberSearchRequest.getGender());             
        baseQuery = checkandMapRelationship(baseQuery,parameters,memberSearchRequest.getRelationshipToSubscriber());
        baseQuery = checkAndMapSourceSystemMemIdFilter(baseQuery,parameters,memberSearchRequest.getSourceSystemMemberIdFilter());                
        baseQuery = checkAndMapMemberSuffixFilter(baseQuery,parameters,memberSearchRequest.getMemberSuffixFilter());                
        baseQuery = checkAndMapGroupIdAndSubGroupId(baseQuery,parameters,memberSearchRequest.getGroupIds(),memberSearchRequest.getSubGroupIds());
                    
        // Adding condtion for enrollmentSystemCodes.
        if (!CollectionUtils.isEmpty(memberSearchRequest.getEnrollmentSystemCodes())) {
            List<String> enrollmentSystemCodeValues = memberSearchRequest.getEnrollmentSystemCodes().stream()
                    .map(EnrollmentSystemCode::getValue).toList();
            baseQuery += " and srce_sys_cd in (:enrollmentSystemCodeValues)";
            parameters.put("enrollmentSystemCodeValues", enrollmentSystemCodeValues);
        }

        //Creating Native SQL Query for Performance Optimization.
        Query query = entityManager.createNativeQuery(baseQuery, MemberCoverageEntity.class);
        for (Map.Entry<String, Object> entry : parameters.entrySet()) {
            query.setParameter(entry.getKey(), entry.getValue());
        }

        return query.getResultList();
        }

    /**
     * This methos is to Check and map GroupId and SubGroupId in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param groupIds
     * @param subGroupIds
     * @param extendSubgroupIdsMatchToDeptNumber
     * @return
     */
    private String checkAndMapGroupIdAndSubGroupId(String baseQuery, HashMap<String, Object> parameters,
            List<String> groupIds, List<String> subGroupIds) {

        String baseQueryNew = baseQuery;
        // Adding condtion for GroupIds 
        if (!CollectionUtils.isEmpty(groupIds)) {
            groupIds.replaceAll(String::toUpperCase);
            baseQueryNew += " and group_id in (:groupIdValues)";
            parameters.put("groupIdValues", groupIds);
        }

        // Adding condtion for subGroupIds 
        if (!CollectionUtils.isEmpty(subGroupIds) ){
            subGroupIds.replaceAll(String::toUpperCase);
            baseQueryNew += " and sub_grp_id in (:subGroupIdValues)";
            parameters.put("subGroupIdValues", subGroupIds);
        }
        return baseQueryNew;
    }

    /**
     * This methos is to Check and map MemberSuffixFilter in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param memberSuffixFilter
     * @return
     */
    private String checkAndMapMemberSuffixFilter(String baseQuery, HashMap<String, Object> parameters,
            List<MemberSuffixFilter> memberSuffixFilter) {

        String baseQueryNew = baseQuery;
        // Adding condition for memberSuffixFilter with memberSuffix and sorceSystemCode
        if (!CollectionUtils.isEmpty(memberSuffixFilter)) {
            List<String> memberSuffixList = memberSuffixFilter.stream()
                    // MemberSuffixFilter
                    .map(MemberSuffixFilter::getMemberSuffix)
                    .filter(Objects::nonNull)
                    .toList();
            if (!CollectionUtils.isEmpty(memberSuffixList)) {
                baseQueryNew += " and cov_json->>'memberSuffix' in (:memberSuffixList)";
                parameters.put("memberSuffixList", memberSuffixList);
            }
            List<String> sourceSystemCodes = new ArrayList<>();

            for (MemberSuffixFilter memberSuffix : memberSuffixFilter) {
                if (null != memberSuffix.getEnrollmentSystemCode()) {
                    sourceSystemCodes.add(memberSuffix.getEnrollmentSystemCode().getValue());
                }
            }

            if (!CollectionUtils.isEmpty(sourceSystemCodes)) {
                baseQueryNew += " and srce_sys_cd in (:sourceSystemCodes)";
                parameters.put("sourceSystemCodes", sourceSystemCodes);
            }
        }
        return baseQueryNew;
    }

    /**
     * This methos is to Check and map SourceSystemMemberIdFilter in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param sourceSystemMemberIdFilter
     * @return
     */
    private String checkAndMapSourceSystemMemIdFilter(String baseQuery, HashMap<String, Object> parameters,
            List<SourceSystemMemberIdFilter> sourceSystemMemberIdFilter) {
        String baseQueryNew = baseQuery;
        // Adding condtion for SourceSystemMemberId filter 
        if (!CollectionUtils.isEmpty(sourceSystemMemberIdFilter)) {
            List<String> sourceSystemMemberIds = sourceSystemMemberIdFilter.stream()
                    // SourceSystemMemberIdFilter
                    .map(SourceSystemMemberIdFilter::getSourceSystemMemberId)
                    .filter(Objects::nonNull)
                    .toList();
            if (!CollectionUtils.isEmpty(sourceSystemMemberIds)) {
                baseQueryNew += " and srce_sys_memb_id in (:sourceSystemMemberIds)";
                parameters.put("sourceSystemMemberIds", sourceSystemMemberIds);
            }
            List<String> sourceSystemCodes = new ArrayList<>();
            for (SourceSystemMemberIdFilter sourceSystemMemberId : sourceSystemMemberIdFilter) {
                if (null != sourceSystemMemberId.getEnrollmentSystemCode()) {
                    sourceSystemCodes.add(sourceSystemMemberId.getEnrollmentSystemCode().getValue());
                }

            }

            if (!CollectionUtils.isEmpty(sourceSystemCodes)) {
                baseQueryNew += " and srce_sys_cd in (:sourceSystemCodes)";
                parameters.put("sourceSystemCodes", sourceSystemCodes);
            }
        }
        return baseQueryNew;
    }

    /**
     * This methos is to Check and map RelationshipToSubscriber in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param relationshipToSubscriber
     * @return
     */
    private String checkandMapRelationship(String baseQuery, HashMap<String, Object> parameters,
            RelationshipToSubscriber relationshipToSubscriber) {

        String baseQueryNew = baseQuery;
        // Adding condtion for relationshipToSubscriber 
        if (!Objects.isNull(relationshipToSubscriber)) {
            baseQueryNew += " and cov_json->>'relationshipToSubscriber' = :relationshipToSubscriber";
            parameters.put("relationshipToSubscriber", relationshipToSubscriber.getValue());
        }

        return baseQueryNew;
    }

    /**
     * This methos is to Check and map FirstName, DateOfBrith and Gender in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param firstName
     * @param exactMatchOnName
     * @param dateOfBirth
     * @param gender
     * @return
     */
    private String checkAndMapFirstNameAndDateOfBirthAndGender(String baseQuery, HashMap<String, Object> parameters,
            String firstName, Boolean exactMatchOnName, LocalDate dateOfBirth, Gender gender) {

        String baseQueryNew = baseQuery;
        // Adding condtion for firstName.
        if (StringUtils.isNotBlank(firstName)) {
            if (exactMatchOnName.booleanValue()) {
                baseQueryNew += " and cov_json->'name'->> 'firstName' = :firstName";
                parameters.put("firstName", firstName);
            } else {
                baseQueryNew += " and cov_json->'name'->> 'firstName' like :firstName";
                parameters.put("firstName", firstName.concat(ApplicationConstants.PERCENTAGE).toUpperCase());
            }
        }

        // Adding condtion for dateOfBirth.
        if (!Objects.isNull(dateOfBirth)) {
            baseQueryNew += " and cov_json->>'dateOfBirth' = :dateOfBirth";
            parameters.put("dateOfBirth", dateOfBirth.toString());
        }

        // Adding condtion for gender.
        if (!Objects.isNull(gender)) {
            baseQueryNew += " and cov_json->>'gender' = :gender";
            parameters.put("gender", gender.getValue());
        }
        return baseQueryNew;
    }

    /**
     * This methos is to Check and map MemberSSN and SubscriberId in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param memberSSN
     * @param partialMatchMemberSSNEndsWith
     * @param subscriberId
     * @return
     */
    private String checkAndMapMemberSSNSubscriberId(String baseQuery, HashMap<String, Object> parameters,
            String memberSSN, Boolean partialMatchMemberSSNEndsWith, String subscriberId) {

        String baseQueryNew = baseQuery;
        if (StringUtils.isNotBlank(memberSSN)) {
            if (partialMatchMemberSSNEndsWith.booleanValue()) {
                baseQueryNew += " and cov_json->>'memberSSN' like :memberSSN";
                parameters.put("memberSSN", "%" + memberSSN);
            } else {
                baseQueryNew += " and cov_json->>'memberSSN' = :memberSSN";
                parameters.put("memberSSN", memberSSN);
            }
        }

        if (StringUtils.isNotBlank(subscriberId)) {
            baseQueryNew += " and (subscriber_id = :subscriberId";
            parameters.put("subscriberId", subscriberId);
            if (subscriberId.length() < 9) {
                baseQueryNew += " or cov_json->>'alternateId' = :subscriberId or cov_json->>'legacyId' = :subscriberId";
            } else {
                baseQueryNew += " or cov_json->>'alternateId' like (:subscriberIdPercent) or cov_json->>'legacyId' like (:subscriberIdPercent)";
                parameters.put("subscriberIdPercent", subscriberId.concat(ApplicationConstants.PERCENTAGE));
            }
            baseQueryNew += ")";
        }
        return baseQueryNew;
    }

    /**
     * This methos is to Check and map MemberLifeId and LastName in Query.
     * 
     * @param baseQuery
     * @param parameters
     * @param memberLifeId
     * @param lastName
     * @param exactMatchOnName
     * @return
     */
    private String checkAndMapMemberLifeIdAndLastName(String baseQuery, HashMap<String, Object> parameters,
            String memberLifeId, String lastName, Boolean exactMatchOnName) {
        String baseQueryNew = baseQuery;
        // Adding condtion for memberLifeId.
        if (StringUtils.isNotBlank(memberLifeId)) {
            baseQueryNew += " and cov_json->>'memberLifeId' = :memberLifeId";
            parameters.put("memberLifeId", memberLifeId.toUpperCase());
        }

        // Adding condtion for lastName.
        if (StringUtils.isNotBlank(lastName)) {
            if (exactMatchOnName.booleanValue()) {
                baseQueryNew += " and cov_json->'name'->> 'lastName' = :lastName";
                parameters.put("lastName", lastName.toUpperCase());
            } else {
                baseQueryNew += " and cov_json->'name'->> 'lastName' like :lastName";
                parameters.put("lastName", lastName + "%".toUpperCase());
            }
        }
        return baseQueryNew;
    }

}
