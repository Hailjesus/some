package com.carefirst.nexus.membersearch.util;

import java.util.List;

/**
 * FilterQueryCriteria class.
 * 
 * @author Author
 *
 */
public class FilterQueryCriteria {

	private List<String> groupIds;

	public FilterQueryCriteria() {
		// default constructor
	}

	public void setGroupIds(List<String> groupIds) {
		this.groupIds = groupIds;
	}

	public List<String> getGroupIds() {
		return groupIds;
	}

}
