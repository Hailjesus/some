/**
 * 
 */
package com.carefirst.nexus.membersearch.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.group.gen.model.GroupAccount;
import com.carefirst.nexus.membersearch.constants.ApplicationConstants;
import com.carefirst.nexus.membersearch.entity.MemberCoverage;
import com.carefirst.nexus.membersearch.entity.MemberCoverageEntity;
import com.carefirst.nexus.membersearch.gen.api.MembersApiDelegate;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberResponse;
import com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.membersearch.helper.MemberSearchHelper;
import com.carefirst.nexus.membersearch.model.MemberSearchV2ApiModel;
import com.carefirst.nexus.membersearch.model.ProtectGroupTypeDataResponse;
import com.carefirst.nexus.membersearch.repository.MemberCoverageEntityManager;
import com.carefirst.nexus.membersearch.util.MemberSearchUtils;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.helpers.ResponseContextHelper;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

import lombok.extern.slf4j.Slf4j;

/**
 * @author carefirst
 *
 */
@Service
@Slf4j
public class MemberSearchV2ApiApiService implements MembersApiDelegate {

	@Value("#{'${application.search.restrict.memberlifeids}'.split(',')}")
	private List<String> listOfRestrictedLifeIds;

	private MemberCoverageEntityManager memberCoverageEntityManager;
	private FEPMemberEligibilityService fepMemberEligibilityService;
	private MemberDerivedDataService memberDerivedDataService;

	MemberSearchV2ApiApiService(MemberCoverageEntityManager memberCoverageEntityManager,
			FEPMemberEligibilityService fepMemberEligibilityService, MemberDerivedDataService memberDerivedDataService) {
		this.memberCoverageEntityManager = memberCoverageEntityManager;
		this.fepMemberEligibilityService = fepMemberEligibilityService;
		this.memberDerivedDataService = memberDerivedDataService;

	}

	/*
	 * Find members takes inputs parameters and performs search after the input
	 * validation conditions meet.
	 */
	@Override
	public ResponseEntity<MemberResponse> findMembers(String memberLifeId,
			String memberSSN,
			String subscriberId,
			String firstName,
			String lastName,
			LocalDate dateOfBirth,
			Gender gender,
			RelationshipToSubscriber relationshipToSubscriber,
			String city,
			String state,
			String zipCode,
			String primaryEmailAddress,
			String primaryPhoneNumber,
			LocalDate startDate,
			LocalDate endDate,
			List<String> groupIds,
			List<GroupFilter> groupFilter,
			String accountId,
			List<ProductCategory> productCategories,
			List<EnrollmentSystemCode> enrollmentSystemCodes,
			List<SourceSystemMemberIdFilter> sourceSystemMemberIdFilter,
			List<MemberSuffixFilter> memberSuffixFilter,
			Boolean expandSearchWithMemberLifeId,
			Boolean exactMatchOnName,
			List<ClaimsSystemCode> claimsSystemCodes,
			List<String> subGroupIds,
			Boolean extendSubgroupIdsMatchToDeptNumber,
			Boolean partialMatchMemberSSNEndsWith,
			Boolean useFemsForFep) {

		MemberSearchV2ApiModel memberSearchRequest = new MemberSearchV2ApiModel(memberLifeId, memberSSN, subscriberId,
				firstName, lastName, dateOfBirth, gender, relationshipToSubscriber, city, state, zipCode,
				primaryEmailAddress, primaryPhoneNumber, startDate, endDate, groupIds, groupFilter, accountId,
				productCategories, enrollmentSystemCodes, sourceSystemMemberIdFilter, memberSuffixFilter,
				expandSearchWithMemberLifeId, exactMatchOnName, claimsSystemCodes, subGroupIds,
				extendSubgroupIdsMatchToDeptNumber, partialMatchMemberSSNEndsWith, useFemsForFep);

		log.info("Member Search || findMembers request params: {}", memberSearchRequest);
		checkAccountIdOfTypeCD(memberSearchRequest);

		// This is restriction added to lifeIds to avoid out of heap memory issue.
		if (isRestrictedMemberLifeId(memberLifeId)) {
			log.error("Member policies search restricted for memberLifeId");
			AppJSONException jsonException = new AppJSONException(ErrorResponseCode.ERROR_VALIDATION_ERROR,
					new String[] { "Member policies search restricted for memberLifeId" });
			jsonException.setStatus(HttpStatus.BAD_REQUEST);
			throw jsonException;
		}

		// Input validation
		MemberSearchHelper.validation(memberSearchRequest);
		MemberSearchHelper.ssnValidation(memberSearchRequest);

		StopWatch watch = new StopWatch("Member Search");
		watch.start();
		List<MemberCoverageEntity> mbrCoverageEntity = null;

		try {
			List<GroupAccount> groupAccounts = null;
			//validate and if accountId starts with CD or MAPD
			if(StringUtils.hasText(accountId) 
				&& (!accountId.toUpperCase().startsWith(ApplicationConstants.CONSUMER_DIRECT_ACCOUNT)
				&& !accountId.toUpperCase().startsWith(ApplicationConstants.MAPD_ACCT_ID_PREFIX))){
					groupAccounts = memberDerivedDataService.fetchGroupAccountDetails(accountId);
					groupFilter = mapGroupFilterAccounts(groupFilter,groupAccounts);
			}
			mbrCoverageEntity = memberCoverageEntityManager.getMemberCoverageEntities(memberSearchRequest);
			watch.stop();
			log.debug("Search by MemberLifeId: {} {}", memberLifeId, watch.prettyPrint());
			watch.start();
			List<MemberCoverageEntity> mbrCoverageEntityFilter = filterCoverageEntities(mbrCoverageEntity,
			memberSearchRequest);
			mbrCoverageEntity = MemberSearchHelper.applyGroupfilterCoverageEntities(mbrCoverageEntityFilter,groupFilter);
			//To Fetch Account related details using Group api
			List<Member> mbrCoverage = new ArrayList<>();
			mbrCoverage.addAll(MemberSearchHelper.convertToModelObject(mbrCoverageEntity));
			Set<String> memAccountDDSet = MemberSearchHelper.getUniqueMbrgroupdetails(mbrCoverage);
			List<ProtectGroupTypeDataResponse> protectedGroupTypes = memberDerivedDataService.fetchProtectedGroupTypeDetails(memAccountDDSet);
			//Map account Info and filter AccountId.
			MemberSearchHelper.mapMemberSearchAccountinfo(mbrCoverage,protectedGroupTypes);
			watch.stop();
			log.debug("Domain to model convertion count: {} Search by MemberLifeId: {} {}",
						mbrCoverage.size(), memberLifeId, watch.prettyPrint());
			watch.start();
			MemberResponse memberResponse = new MemberResponse();
			if (null != useFemsForFep && useFemsForFep.booleanValue()) {
				mbrCoverage = fepMemberEligibilityService.checkAndUpdateFepMemberData(
					mbrCoverage,
						subscriberId, memberLifeId, memberSuffixFilter);
			} 
			memberResponse.setMember(mbrCoverage);
			memberResponse.setCount(mbrCoverage.size());
			memberResponse.setResponseContext(ResponseContextHelper.createSuccessResponseContext(HttpStatus.OK));
			watch.stop();

			log.debug("Create response context count: {} Search by MemberLifeId: {} {}",
			mbrCoverage.size(), memberLifeId, watch.prettyPrint());
			return new ResponseEntity<>(memberResponse, HttpStatus.OK);

		} catch (Exception e) {
			log.error("Member policies search system error", e);
			Thread.currentThread().interrupt();
			throw new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR);
		}
	}

	/**
	 * @param memberCoverageEntities
	 * @param memberSearchRequest
	 * @return
	 */
	public List<MemberCoverageEntity> filterCoverageEntities(List<MemberCoverageEntity> memberCoverageEntities,
	MemberSearchV2ApiModel memberSearchRequest) {
		List<MemberCoverageEntity> filteredCoverageEntities = new ArrayList<>();
		if (!CollectionUtils.isEmpty(memberSearchRequest.getSourceSystemMemberIdFilter())) {
			memberCoverageEntities = memberCoverageEntities.stream()
					.filter(predicate -> memberSearchRequest.getSourceSystemMemberIdFilter().stream()
							.anyMatch(sourceSystemMemberIdFilter -> null != sourceSystemMemberIdFilter.getSourceSystemMemberId()
									&& predicate.getSourceSystemMemberId()
											.equals(sourceSystemMemberIdFilter.getSourceSystemMemberId())
									&& (null == sourceSystemMemberIdFilter.getEnrollmentSystemCode()
											|| (null != sourceSystemMemberIdFilter.getEnrollmentSystemCode()
													&& predicate.getEnrollmentSystemCode()
															.equals(sourceSystemMemberIdFilter.getEnrollmentSystemCode()
																	.getValue())))))
					.toList();
		}
		
		for (MemberCoverageEntity covgEntity : memberCoverageEntities) {
			MemberCoverageEntity filteredeEntity = covgEntity;
			if (null != covgEntity.getMemberDetails()
					&& !CollectionUtils.isEmpty(covgEntity.getMemberDetails().getMemberCoverages())) {
				List<MemberCoverage> memberCoverages = filerProductClaimAndDates(covgEntity,memberSearchRequest);
				filteredeEntity.getMemberDetails().getMemberCoverages().clear();
				filteredeEntity.getMemberDetails().setMemberCoverages(memberCoverages);
				filteredCoverageEntities.add(filteredeEntity);
			}
		}
		filteredCoverageEntities
				.removeIf(predicate -> CollectionUtils.isEmpty(predicate.getMemberDetails().getMemberCoverages()));
		return filteredCoverageEntities;
	}
	
	/**
	 * @param covgEntity
	 * @param memberSearchRequest
	 * @return
	 */
	private List<MemberCoverage> filerProductClaimAndDates(MemberCoverageEntity covgEntity,
			MemberSearchV2ApiModel memberSearchRequest) {
				List<MemberCoverage> memberCoverages = covgEntity.getMemberDetails().getMemberCoverages().stream()
				.filter(predicate -> StringUtils.hasText(predicate.getProductCategory()))
				.toList();
		if (!CollectionUtils.isEmpty(memberSearchRequest.getProductCategories())) {
			memberCoverages = memberCoverages.stream()
					.filter(predicate -> memberSearchRequest.getProductCategories()
							.contains(ProductCategory.fromValue(predicate.getProductCategory())))
					.toList();
		}
		if (!CollectionUtils.isEmpty(memberSearchRequest.getClaimsSystemCodes())) {
			memberCoverages = memberCoverages.stream()
					.filter(predicate -> (StringUtils.hasText(predicate.getClaimsSystemCode())
							&& memberSearchRequest.getClaimsSystemCodes()
									.contains(ClaimsSystemCode.fromValue(predicate.getClaimsSystemCode()))))
					.toList();
		}
		return MemberSearchUtils.filterCoveragesBasedOnDates(memberSearchRequest.getStartDate(), memberSearchRequest.getEndDate(), memberCoverages);
	}

	/**
	 * This method is to accounts group filters.
	 * 
	 * @param groupFilter
	 * @param groupAccounts
	 * @return
	 */
	private List<GroupFilter> mapGroupFilterAccounts(List<GroupFilter> groupFilter, List<GroupAccount> groupAccounts) {
		List<GroupFilter> groupFilterNew = new ArrayList<>();
		//when groupAccount has data the will map accountId and accountName 
		if(ObjectUtils.isNotEmpty(groupAccounts) && !groupAccounts.isEmpty()){
			groupAccounts.stream().filter(ObjectUtils::isNotEmpty).forEach(grpAcct->
				grpAcct.getGroupAssociations().stream().filter(ObjectUtils::isNotEmpty).forEach(grpAssociation->{
					GroupFilter grpFilter = new GroupFilter();
					grpFilter.setGroupId(grpAssociation.getGroupId());
					grpFilter.setGroupAssoicationStartDate(grpAssociation.getGroupAssociationStartDate().toString());
					grpFilter.setGroupAssoicationEndDate(grpAssociation.getGroupAssociationEndDate().toString());
					groupFilterNew.add(grpFilter);
				})
			);
		}
		if(ObjectUtils.isNotEmpty(groupFilterNew) && !groupFilterNew.isEmpty()){
			if(ObjectUtils.isNotEmpty(groupFilter)){
				groupFilter.addAll(groupFilterNew);
			}else{
				groupFilter = groupFilterNew;
			}
		}
		return groupFilter;
	}

	/**
	 * @param memberLifeId
	 * @return
	 */
	public boolean isRestrictedMemberLifeId(String memberLifeId) {
		if (StringUtils.hasText(memberLifeId) && !CollectionUtils.isEmpty(listOfRestrictedLifeIds)) {
			List<String> listOfRestrictedLifeIdsCleansed = listOfRestrictedLifeIds.stream().map(String::trim)
					.toList();
			return listOfRestrictedLifeIdsCleansed.contains(memberLifeId.trim());
		}
		return false;
	}

	/**
	 * This methos is to check account is CD, if CD set AccountId and GroupsIds
	 * 
	 * @param request
	 */
	private void checkAccountIdOfTypeCD(MemberSearchV2ApiModel request) {
		if (StringUtils.hasText(request.getAccountId())
				&& (request.getAccountId().toUpperCase().startsWith(ApplicationConstants.CONSUMER_DIRECT_ACCOUNT)
				|| request.getAccountId().toUpperCase().startsWith(ApplicationConstants.MAPD_ACCT_ID_PREFIX))) {

			List<String> groupIdList = MemberSearchUtils.generateGroupList(request.getAccountId());

			if (!CollectionUtils.isEmpty(request.getGroupIds())
					&& !CollectionUtils.isEmpty(groupIdList)) {
				request.getGroupIds().addAll(groupIdList);
			} else if (!CollectionUtils.isEmpty(groupIdList)) {
				request.setGroupIds(groupIdList);
			}
		} 
	}

}