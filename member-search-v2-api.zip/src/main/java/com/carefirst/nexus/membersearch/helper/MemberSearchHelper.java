package com.carefirst.nexus.membersearch.helper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.carefirst.nexus.membersearch.constants.ApplicationConstants;
import com.carefirst.nexus.membersearch.entity.MemberCoverage;
import com.carefirst.nexus.membersearch.entity.MemberCoverageDetails;
import com.carefirst.nexus.membersearch.entity.MemberCoverageEntity;
import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberDescriptor;
import com.carefirst.nexus.membersearch.gen.model.Name;
import com.carefirst.nexus.membersearch.model.MemberSearchV2ApiModel;
import com.carefirst.nexus.membersearch.model.ProtectGroupTypeDataResponse;
import com.carefirst.nexus.membersearch.util.MemberSearchUtils;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

@Component
public class MemberSearchHelper {

	private static final Logger LOG = LogManager.getLogger(MemberSearchHelper.class);
	protected static final Set<String> STANALONE_DENTAL_ON_EXCHG_CLASS_IDS =  Stream.of("XG01","XG02","XG05","XG07","XG10","XG11","XG14","XG16").collect(Collectors.toCollection(HashSet::new));
	protected static final Set<String> ON_EXCHG_GRP_TYPES =  Stream.of("DCXC","DMXC","MDXC","MIXC","VAXC","VIXC").collect(Collectors.toCollection(HashSet::new));

	private MemberSearchHelper() {
		super();
	}

	/**
	 * Convert MemberSearchEntity to Member Model object.
	 * 
	 * @param mbrSearchEntity mbrSearchEntity
	 * @return Member object.
	 */
	public static List<Member> convertToModelObject(List<MemberCoverageEntity> memberCoverageEntity) {

		// TO DO
		List<Member> response = new ArrayList<>();
		for (MemberCoverageEntity mbrCovEntity : memberCoverageEntity) {
			MemberCoverageDetails memberDetails = mbrCovEntity.getMemberDetails();
			List<MemberCoverage> memberCoverages = memberDetails.getMemberCoverages();
			for (MemberCoverage mbrcov : memberCoverages) {
				Member memberModel = new Member();
				memberModel.setProductCategory(MemberSearchUtils.productCategoryMapper(mbrcov.getProductCategory()));
				memberModel.setPlanCode(MemberSearchUtils.planCodeMapper(mbrcov.getProduct()));

				// Subgroup/Department Mapping
				memberModel.setDeptNumber(mbrcov.getDeptNumber());
				memberModel.setSubGroupId(mbrCovEntity.getSubGroupId());
				memberModel.setMemberIdPrefix(mbrcov.getMemberPrefix());
				memberModel.setBenefitId(MemberSearchUtils.benefitIdMapper(mbrcov.getProduct()));

				// Coverage Date
				memberModel.setEffectiveDate(mbrcov.getEnrollmentFromDate());
				memberModel.setTerminationDate(mbrcov.getEnrollmentThruDate());

				// Member Descriptor
				MemberDescriptor descriptor = new MemberDescriptor();
				descriptor.setAlternateId(memberDetails.getAlternateId());
				descriptor.setDateofBirth(memberDetails.getDateOfBirth());
				descriptor.setGender(MemberSearchUtils.genderMapper(memberDetails.getGender()));
				descriptor.setGroupId(mbrCovEntity.getGroupId());
				descriptor.setLegacyId(memberDetails.getLegacyId());
				descriptor.setMemberLifeId(memberDetails.getMemberLifeId());
				descriptor.setMemberSSN(memberDetails.getMemberSSN());
				descriptor.setSubscriberId(mbrCovEntity.getSubscriberId());
				descriptor.setSourceSystemMemberId(mbrCovEntity.getSourceSystemMemberId());
				descriptor.setEnrollmentSystemCode(
						MemberSearchUtils.enrollmentSystemCodeMapper(mbrCovEntity.getEnrollmentSystemCode()));
				descriptor.setRelationshipToSubscriber(
						MemberSearchUtils.relToSubscriberMapper(memberDetails.getRelationshipToSubscriber()));
				descriptor.setMemberSuffix(memberDetails.getMemberSuffix());

				// Name mapping
				if(ObjectUtils.isNotEmpty(memberDetails.getName())){
					Name name = new Name();
					name.setFirstName(memberDetails.getName().getFirstName());
					name.setLastName(memberDetails.getName().getLastName());
					name.setMiddleName(memberDetails.getName().getMiddleName());
					descriptor.setName(name);
				}

				// auditUpdateTimestamp mapping
				memberModel.setMemberDescriptor(descriptor);

				// Legal Entity Mapping.
				memberModel.setLegalEntity(
						MemberSearchUtils.legalEntityMapper(mbrcov.getProduct()));

				memberModel.setProductId(MemberSearchUtils.productCodeMapper(mbrcov.getProduct()));
				memberModel.setPackageClassId(mbrcov.getPackageClassId());
				memberModel.setClaimsSystemCode(MemberSearchUtils.mapClaimsSystemCode(mbrcov.getClaimsSystemCode()));
				response.add(memberModel);
			}
		}

		return response;
	}

	public static Set<String> getUniqueMbrgroupdetails(List<Member> mbrCoverage) {
		Set<String> groupIdSet = new HashSet<>();
		if (ObjectUtils.isNotEmpty(mbrCoverage)) {
			mbrCoverage.stream().distinct().filter(ObjectUtils::isNotEmpty).forEach(mce -> {
				if (ObjectUtils.isNotEmpty(mce.getMemberDescriptor())) {

					groupIdSet.add(mce.getMemberDescriptor().getGroupId());
				}
			});
		}
		return groupIdSet;
	}

	/**
	 * Method to performs primary & secondary validation of required field.
	 * 
	 * @param MemberSearchV2ApiModel
	 */
	public static void validation(MemberSearchV2ApiModel memberSearchRequest) {
		if (!primaryValidation(memberSearchRequest) && !secondaryValidation(memberSearchRequest)) {
			AppJSONException jsonException = new AppJSONException(ErrorResponseCode.ERROR_VALIDATION_ERROR,
					new String[] { ApplicationConstants.VALIDATION_MSG });
			jsonException.setStatus(HttpStatus.BAD_REQUEST);
			LOG.error("Primary and secondary validation element missing as part of search criteria ",
					jsonException);
			throw jsonException;
		}
	}

	/**
	 * Method to performs primary validation.
	 * 
	 * @param memberSearchRequest
	 * 
	 */
	private static boolean primaryValidation(MemberSearchV2ApiModel memberSearchRequest) {
		boolean primaryValidation = false;
		if (StringUtils.isNotBlank(memberSearchRequest.getMemberLifeId())
				|| StringUtils.isNotBlank(memberSearchRequest.getSubscriberId())
				|| StringUtils.isNotBlank(memberSearchRequest.getMemberSSN())
				|| !CollectionUtils.isEmpty(memberSearchRequest.getSourceSystemMemberIdFilter())) {
			primaryValidation = true;
		}
		return primaryValidation;
	}

	/**
	 * Method to performs secondary validation.
	 * 
	 * @param memberSearchRequest
	 * 
	 */
	private static boolean secondaryValidation(MemberSearchV2ApiModel memberSearchRequest) {
		boolean secondaryValidation = false;
		if ((StringUtils.isNotBlank(memberSearchRequest.getLastName())
				&& !Objects.isNull(memberSearchRequest.getDateOfBirth()))
				|| (StringUtils.isNotBlank(memberSearchRequest.getLastName())
						&& StringUtils.isNotBlank(memberSearchRequest.getFirstName()))
				|| (StringUtils.isNotBlank(memberSearchRequest.getFirstName())
						&& !Objects.isNull(memberSearchRequest.getDateOfBirth()))) {
			secondaryValidation = true;
		}
		return secondaryValidation;
	}

	/**
	 * Method to performs ssn validation of required field.
	 * 
	 * @param memberSearchRequest
	 * 
	 */
	public static boolean ssnValidation(MemberSearchV2ApiModel memberSearchRequest) {
		if (null != memberSearchRequest.getPartialMatchMemberSSNEndsWith()
				&& memberSearchRequest.getPartialMatchMemberSSNEndsWith()
				&& StringUtils.isNotBlank(memberSearchRequest.getMemberSSN())
				&& isSearchBySsnOnly(memberSearchRequest)) {
			AppJSONException jsonException = new AppJSONException(ErrorResponseCode.ERROR_VALIDATION_ERROR,
					new String[] { ApplicationConstants.SSN_VALIDATION_MSG });
			jsonException.setStatus(HttpStatus.BAD_REQUEST);
			LOG.error("{} {}", ApplicationConstants.SSN_VALIDATION_MSG, jsonException);
			throw jsonException;
		}
		return true;
	}

	/**
	 * 4 digit ssn +
	 * (dob/memberLifeid/subscriberId)
	 * 
	 * @param memberSearchRequest
	 * 
	 * @return
	 */
	private static boolean isSearchBySsnOnly(MemberSearchV2ApiModel memberSearchRequest) {
		return !(StringUtils.isNotBlank(memberSearchRequest.getMemberLifeId())
				|| StringUtils.isNotBlank(memberSearchRequest.getSubscriberId())
				|| (null != memberSearchRequest.getDateOfBirth()));

	}

	/**
	 * This method is to map Account info to main response.
	 * 
	 * @param mbrCoverage
	 * @param groupAccounts 
	 * @param groupAccounts
	 * @param protectedGroupTypes 
	 */
	public static void mapMemberSearchAccountinfo(List<Member> mbrCoverage, List<ProtectGroupTypeDataResponse> protectedGroupTypes) {
		
		mbrCoverage.stream().filter(ObjectUtils::isNotEmpty).forEach(member->{
			if(ObjectUtils.isNotEmpty(member.getMemberDescriptor()) && ObjectUtils.isNotEmpty(protectedGroupTypes)){
				//mapping protectedGroupType
					protectedGroupTypes.stream().filter(maddres->(ObjectUtils.isNotEmpty(maddres))
					&& member.getMemberDescriptor().getGroupId().equals(maddres.getGroupId()))
					.forEach(maddres->
						member.getMemberDescriptor().setProtectedGroupType(maddres.getProtectedGroupType())
					);
			}
		});
	}

	/**
	 * This method is to groupFilter to the coverage DDS.
	 * 
	 * @param memberCoverageEntities
	 * @param groupFilter
	* @param groupAccounts 
	* @return
	*/
	public static List<MemberCoverageEntity> applyGroupfilterCoverageEntities(List<MemberCoverageEntity> memberCoverageEntities,List<GroupFilter> groupFilter) {
		
		if (!CollectionUtils.isEmpty(groupFilter) && !CollectionUtils.isEmpty(memberCoverageEntities)
		&& !memberCoverageEntities.isEmpty()) {
			memberCoverageEntities = memberCoverageEntities.stream()
					.filter(predicate -> groupFilter.stream()
							.anyMatch(grpFilter -> null != grpFilter.getGroupId()
									&& predicate.getGroupId()
											.equals(grpFilter.getGroupId())))
					.toList();
			//Filter enrollment startDate endDate.
			memberCoverageEntities.stream().filter(ObjectUtils::isNotEmpty).forEach(memCovEnt->{
				MemberCoverageDetails memcovDetails = memCovEnt.getMemberDetails();
				if(ObjectUtils.isNotEmpty(memcovDetails) && null!=memcovDetails.getMemberCoverages() && StringUtils.isNotBlank(memCovEnt.getGroupId())){
					groupFilter.stream().filter(grpFilter->ObjectUtils.isNotEmpty(grpFilter) && memCovEnt.getGroupId().equals(grpFilter.getGroupId())).forEach(grpFilter->
						memcovDetails.setMemberCoverages(MemberSearchUtils.filterCoveragesBasedOnDates(LocalDate.parse(grpFilter.getGroupAssoicationStartDate()),LocalDate.parse(grpFilter.getGroupAssoicationEndDate()),memcovDetails.getMemberCoverages()))
					);
				}
				memCovEnt.setMemberDetails(memcovDetails);
			});
		}
		return memberCoverageEntities;
	}
				
}
