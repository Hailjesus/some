package com.carefirst.nexus.membersearch.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.fepmembercoverage.gen.api.FepmemberCoverageApi;
import com.carefirst.nexus.fepmembercoverage.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.fepmembercoverage.gen.model.FepMemberCoveragesResponse;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.fepmembercoverage.gen.model.SupplementaryFepCoverageDetailsResponse;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.helper.FEPMemberHelper;
import com.carefirst.nexus.membersearch.model.FEPMemberSupplementaryCovDtlsRequest;
import com.carefirst.nexus.membersearch.model.FepMemberCoverageRequest;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class FEPMemberEligibilityService {

	private FepmemberCoverageApi fepmemberCoverageApi;

	public FEPMemberEligibilityService(FepmemberCoverageApi fepmemberCoverageApi) {
		this.fepmemberCoverageApi = fepmemberCoverageApi;
	}
	
	public List<Member> checkAndUpdateFepMemberData(List<Member> ddsMembers, String inputSubscriberId, String inputMemberLifeId,
			List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters) {
		log.info("> FEMS flow starts ->> checkAndUpdateFepMemberData");
		log.debug("> checkAndUpdateFepMemberData");
		
		
		
		List<Member> finalmembers = new ArrayList<>();
		List<MemberSuffixFilter> inputTransformedSuffixFilters = transformMbrSuffixToFepEligiSuffix(inputMbrSuffixFilters,inputMemberLifeId);
		

		if (CollectionUtils.isEmpty(ddsMembers)) {
			log.info(">DDS has no members");
			String subId = FEPMemberHelper.extractSubscriberId(inputSubscriberId, inputMemberLifeId);
			//restrict call to fep if subId null
			if(StringUtils.hasText(subId)){
				List<MemberCoverage> fepCoveragesList = getFepMemberCoverages(subId, inputMemberLifeId, inputTransformedSuffixFilters);
				finalmembers = FEPMemberHelper.transformCoverageTypeToMemberSearchList(fepCoveragesList);
			}
		
		} else {

			log.info(">DDS has members");
			List<Member> nonFepMembers = FEPMemberHelper.filterNonFEPMembers(ddsMembers);
			List<Member> fepMembers = FEPMemberHelper.filterFEPMembers(ddsMembers);
			List<MemberCoverage> fepCoveragesList = null;

			if (CollectionUtils.isEmpty(fepMembers)) {
				log.info(">DDS does not have FEP members");
				fepCoveragesList = getFepMemberCoverages(inputSubscriberId, inputMemberLifeId, inputTransformedSuffixFilters);

			} else {
				log.info(">DDS has FEP members");
				List<String> subscriberIdSuffixDistinct = new ArrayList<>();
				if(StringUtils.hasText(inputMemberLifeId)){
					subscriberIdSuffixDistinct = FEPMemberHelper.getDistinctSubscriberIdSuffix(fepMembers);
				}else{
					subscriberIdSuffixDistinct.add(inputSubscriberId);
				}
				
				fepCoveragesList = collectCoveragesEachSubIdSuffix(inputMemberLifeId, inputTransformedSuffixFilters,
						subscriberIdSuffixDistinct);
			}
				
			List<Member> fepMembersDataUpdated = FEPMemberHelper.transformCoverageTypeToMemberSearchList(fepCoveragesList);
			finalmembers = FEPMemberHelper.addAll(finalmembers, fepMembersDataUpdated);
			finalmembers = FEPMemberHelper.addAll(finalmembers, nonFepMembers);
		}
		log.debug("< checkAndUpdateFepMemberData");
		log.info("< FEMS flow ends ->> checkAndUpdateFepMemberData");
		return finalmembers;	
	}

	private List<MemberCoverage> collectCoveragesEachSubIdSuffix(String inputMemberLifeId,
			List<MemberSuffixFilter> inputTransformedSuffixFilters, List<String> subscriberIdSuffixDistinct) {
		log.debug("> collectCoveragesEachSubIdSuffix");
		List<MemberCoverage> fepCoveragesList = new ArrayList<>();
		
		for (String subIdSuffix : subscriberIdSuffixDistinct) {
			List<MemberSuffixFilter> memberSuffixFilterList = new ArrayList<>();
			String[] tokens = subIdSuffix.split("_");
			String subId = tokens[0];
			if (tokens.length == 2 && StringUtils.hasText(tokens[1])) {
				memberSuffixFilterList = mapFEPSuffixFilter(tokens[1]);
			}
			memberSuffixFilterList = FEPMemberHelper.addAll(memberSuffixFilterList, inputTransformedSuffixFilters);
			List<MemberCoverage> fepListForSubId = getFepMemberCoverages(subId, inputMemberLifeId, memberSuffixFilterList);
			fepCoveragesList = FEPMemberHelper.addAll(fepCoveragesList, fepListForSubId);
		}
		log.debug("< collectCoveragesEachSubIdSuffix");
		return fepCoveragesList;
	}

	/**
	 * Transforms MemberSuffixFilter to FepEligibilitySuffixFilter.
	 * 
	 * @param memberSuffixFilters
	 * @return
	 */
	private List<MemberSuffixFilter> transformMbrSuffixToFepEligiSuffix(
			List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> memberSuffixFilters,String inputMemberLifeId) {
		List<MemberSuffixFilter> fepEligbilitySuffixFilterList = null;
		MemberSuffixFilter fepEligiSuffixFilter = new MemberSuffixFilter();
		if (!CollectionUtils.isEmpty(memberSuffixFilters)) {
			fepEligbilitySuffixFilterList = new ArrayList<>();
			for (com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter memberSuffixFilter : memberSuffixFilters) {
				
				fepEligiSuffixFilter.setMemberSuffix(memberSuffixFilter.getMemberSuffix());
				if (null != memberSuffixFilter.getEnrollmentSystemCode()) {
					fepEligiSuffixFilter.setEnrollmentSystemCode(EnrollmentSystemCode.fromValue(memberSuffixFilter.getEnrollmentSystemCode().toString()));
				}
				fepEligbilitySuffixFilterList.add(fepEligiSuffixFilter);
			}
		} else {
			if ( (StringUtils.hasText(inputMemberLifeId)) && (inputMemberLifeId.startsWith("T060") || inputMemberLifeId.startsWith("T064")) && (inputMemberLifeId.length() == 15)){
				fepEligbilitySuffixFilterList = new ArrayList<>();
				String memberLifeIdMemberSuffix= inputMemberLifeId.substring(13, 15);
				fepEligiSuffixFilter.setMemberSuffix(memberLifeIdMemberSuffix);
				fepEligiSuffixFilter.setEnrollmentSystemCode(EnrollmentSystemCode.fromValue( inputMemberLifeId.substring(1, 4)));
				fepEligbilitySuffixFilterList.add(fepEligiSuffixFilter);
			}
		}
		return fepEligbilitySuffixFilterList;
	}

	
	/**
	 * Map to pass distinct suffix to fepEligibility in form of FEPSuffixFilter.
	 * Setting enrollmentSysCode always to FEP type since call happens only for
	 * FEP type data.
	 * 
	 * @param suffix
	 * @return
	 */
	private List<MemberSuffixFilter> mapFEPSuffixFilter(String suffix) {
		List<MemberSuffixFilter> memberSuffixfilterList = new ArrayList<>();

		MemberSuffixFilter sufFilterDC = new MemberSuffixFilter();
		sufFilterDC.setMemberSuffix(suffix);
		sufFilterDC.setEnrollmentSystemCode(EnrollmentSystemCode.FEP_DC);

		MemberSuffixFilter sufFilterMD = new MemberSuffixFilter();
		sufFilterMD.setMemberSuffix(suffix);
		sufFilterMD.setEnrollmentSystemCode(EnrollmentSystemCode.FEP_MD);

		memberSuffixfilterList.add(sufFilterMD);
		memberSuffixfilterList.add(sufFilterDC);
		return memberSuffixfilterList;
	}

	public List<MemberCoverage> getFepMemberCoverages(String subscriberId,
			String memberLifeId, List<MemberSuffixFilter> memberSuffixFilter) {
		FepMemberCoverageRequest request = new FepMemberCoverageRequest();
		request.setSubscriberId(subscriberId);
		request.setMemberSuffixFilter(memberSuffixFilter);
		request.setMemberLifeId(memberLifeId);
		log.info("> fepmember-eligibility | findFepMemberCoverages request param values :: {} ", request);
		FepMemberCoveragesResponse response = findFepMemberCoverages(request);
		if (null != response) {
			//remove the below check and apply call onces suffix filter is handled properly in fepMember-eligibility-ms.
			if(!CollectionUtils.isEmpty(memberSuffixFilter) && !CollectionUtils.isEmpty(response.getMemberCoverages())){
				return applySuffixFilter(memberSuffixFilter, response);
			}
			return response.getMemberCoverages();
		}
		return new ArrayList<>();
	}
	

	private List<MemberCoverage> applySuffixFilter(List<MemberSuffixFilter> memberSuffixFilter,
			FepMemberCoveragesResponse response) {
		log.debug("> applySuffixFilter");
		List<MemberCoverage> coverages = response.getMemberCoverages();

		List<String> suffixes = memberSuffixFilter.stream()
				.filter(f -> StringUtils.hasText(f.getMemberSuffix()))
				.map(MemberSuffixFilter::getMemberSuffix)
				.toList();
		
		List<EnrollmentSystemCode> enrollSysCodes = memberSuffixFilter.stream()
				.filter(f -> null != f.getEnrollmentSystemCode())
				.map(MemberSuffixFilter::getEnrollmentSystemCode)
				.toList();

		if (!CollectionUtils.isEmpty(suffixes)) {
			coverages = coverages.stream().filter(c -> suffixes.contains(c.getMemberDescriptor().getMemberSuffix()))
					.toList();
		}

		if (!CollectionUtils.isEmpty(enrollSysCodes) && !CollectionUtils.isEmpty(coverages)) {
			coverages = coverages.stream()
					.filter(c -> enrollSysCodes.contains(c.getMemberDescriptor().getEnrollmentSystemCode()))
					.toList();
		}
		log.debug("> applySuffixFilter");
		return coverages;
	}

	/**
	 * Find FEP member coverages based on parameters.
	 * 
	 * @param request
	 * @return
	 */
	public FepMemberCoveragesResponse findFepMemberCoverages(FepMemberCoverageRequest request) {
		FepMemberCoveragesResponse response = null;
		try {
			Mono<FepMemberCoveragesResponse> monoResponse = fepmemberCoverageApi.getFEPMemberCoverages(
					request.getSubscriberId(), request.getMemberLifeId(), request.getStartDate(), request.getEndDate(),
					request.getGroupIds(), request.getEnrollmentSystemCodes(), request.getClaimsSystemCodes(),
					request.getSourceSystemMemberIdFilter(), request.getMemberSuffixFilter());

			if (null != monoResponse) {
				response = monoResponse.block();
			}
		} catch (Exception e) {
			log.error("Exception caught while fepmemberCoverageApi getFEPMemberCoverages :: " + e.getMessage(), e);
		}
		return response;

	}

	/**
	 * Get supplimentary FEP coverage details based on parameters.
	 * 
	 * @param request
	 * @return
	 */
	public SupplementaryFepCoverageDetailsResponse getSupplementaryFEPCoverageDetails(
			FEPMemberSupplementaryCovDtlsRequest request) {
		SupplementaryFepCoverageDetailsResponse response = null;
		try {
			Mono<SupplementaryFepCoverageDetailsResponse> monoResponse = fepmemberCoverageApi
					.getSupplementaryFEPCoverageDetails(request.getRecordType(), request.getSubscriberId(),
							request.getMemberLifeId(), request.getGroupIds(), request.getSourceSystemMemberIdFilter(),
							request.getMemberSuffixFilter());

			if (null != monoResponse) {
				response = monoResponse.block();
			}
		} catch (Exception e) {
			log.error("Exception caught while fepmemberCoverageApi getSupplementaryFEPCoverageDetails :: " + e.getMessage(), e);
		}
		return response;
	}

}
