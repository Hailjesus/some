package com.carefirst.nexus.membersearch.constants;

public class ApplicationConstants {
	
	private ApplicationConstants() {}
	
	public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
	public static final String PERCENTAGE = "%";
	public static final String PRIMARY_ERROR_MSG = "memberLifeId/subscriberId/primaryEmailAddress/primaryPhoneNumber/memberSSN/sourceSystemMemberIdFilter is required for search";
	public static final String PARSE_DATE_ERROR_MSG = "MM/dd/yyyy date format only supported";
	public static final String CONSUMER_DIRECT_ACCOUNT = "CD";
	public static final String STRING_DOT ="\\.";
	public enum INDICATOR {
		Y,N
	}
	
	public enum ACCOUNT_TYPE {

		MEDICAID_MD("8675309", "MD MEDICAID"), MEDICAID_DC("41750197", "DC MEDICAID"), WEL("WO",
		WO_ACCT_NAME), TMG("MAPD", "CAREFIRST ADVANTAGE, INC.");

		public final String id;
		public final String label;

		private ACCOUNT_TYPE(String id, String label) {
			this.id = id;
			this.label = label;
		}

		public String getId() {
			return this.id;
		}

		public String getLabel() {
			return this.label;
		}
	}
	public static final String DOT = ".";
	public static final String CD = "CD";
	
	public static final String VALIDATION_MSG = "Minimun search criteria not met. Please provide memberLifeId/subscriberId/memberSSN/sourceSystemMemberIdFilter or combination of firstName, lastName and dateOfBirth";
	public static final String SSN_VALIDATION_MSG = "Minimun search criteria not met. Please provide 4 digit ssn + dob/memberLifeid/subscriberId/";
	public static final String STANALONE_DENTAL_GRP_PRFX = "99D";
	public static final String ACCT_ID_DELIM = ".";
	public static final String CD_ACCT_ID_PREFIX = "CD";
	public static final String CD_STUDENT_ACCT_ID_PREFIX = "CDS";
	public static final String CD_ACA_ACCT_ID_PREFIX = "CDA";
	public static final String CD_ACA_ONEXCH_ACCT_ID_PREFIX = "CDAX";
	public static final String MAPD_ACCT_ID_PREFIX = "MAPD";
	public static final String WO_ACCT_ID = "WO";
	public static final String WO_ACCT_NAME = "Wellness Only / Uninsured";
	public static final String OTHER = "other";

}
