package com.carefirst.nexus.membersearch.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.GenericConverter;
import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;

import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.utils.web.jackson.JacksonEnumConverter;
import com.carefirst.nexus.utils.web.jackson.JacksonObjectConverter;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class JacksonConverterConfig {


	private ObjectMapper getObjectMapper() {
		return new ObjectMapper();
	}

	@Bean
	public GenericConverter jacksonObjectConverter() {
		log.debug("> jacksonObjectConverter");
		Set<ConvertiblePair> typePairs = new HashSet<>();
		typePairs.add(new ConvertiblePair(String.class, GroupFilter.class));
		typePairs.add(new ConvertiblePair(String.class, MemberSuffixFilter.class));
		typePairs.add(new ConvertiblePair(String.class, SourceSystemMemberIdFilter.class));
		return new JacksonObjectConverter(typePairs, getObjectMapper());
	}

	@Bean
	public GenericConverter jacksonEnumConverter() {
		log.debug("> jacksonEnumConverter");
		return new JacksonEnumConverter(getObjectMapper());
	}
}
