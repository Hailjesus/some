package com.carefirst.nexus.membersearch.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.group.gen.model.ASUIndicator;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.LegalEntity;
import com.carefirst.nexus.membersearch.gen.model.LocalBlueShieldPlanCode;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;

public class EnumUtil {
	
	private static final Logger LOG = LogManager.getLogger(EnumUtil.class);
	private static final String ILLEGAL_ARG_EXCEPTION = "IllegalArgumentException caught";
	
	private EnumUtil(){}
	
	private static final Map<String, String> MEIDS_RELTP_CD_MAP = new HashMap<>();
	
	static{
		MEIDS_RELTP_CD_MAP.put("01", "18");
		MEIDS_RELTP_CD_MAP.put("02", "01");
		MEIDS_RELTP_CD_MAP.put("20", "01");
		MEIDS_RELTP_CD_MAP.put("21", "01");
		MEIDS_RELTP_CD_MAP.put("04", "19");
		MEIDS_RELTP_CD_MAP.put("05", "19");
		MEIDS_RELTP_CD_MAP.put("06", "22");
		MEIDS_RELTP_CD_MAP.put("07", "19");
		MEIDS_RELTP_CD_MAP.put("03", "23");
		MEIDS_RELTP_CD_MAP.put("00", "34");
		MEIDS_RELTP_CD_MAP.put("98", "34");
	}
	
	private static final Map<String,String> PROD_CATEGORY_MAP = new HashMap<>();
	static {
		PROD_CATEGORY_MAP.put("01","DEN");
		PROD_CATEGORY_MAP.put("02","DRG");
		PROD_CATEGORY_MAP.put("03","VIS");
		PROD_CATEGORY_MAP.put("04","LIF");
		PROD_CATEGORY_MAP.put("05","MED");
		PROD_CATEGORY_MAP.put("07","DIS");
		PROD_CATEGORY_MAP.put("11","HRG");
		PROD_CATEGORY_MAP.put("15","CAT");
		PROD_CATEGORY_MAP.put("18","WEL");
		PROD_CATEGORY_MAP.put("19","DMM");
		PROD_CATEGORY_MAP.put("23","LIF");
		PROD_CATEGORY_MAP.put("24","ADD");
		PROD_CATEGORY_MAP.put("25","LIF");
		PROD_CATEGORY_MAP.put("28","LIF");
		PROD_CATEGORY_MAP.put("29","ADD");
		PROD_CATEGORY_MAP.put("30","LIF");
		PROD_CATEGORY_MAP.put("31","ADD");
		PROD_CATEGORY_MAP.put("32","LIF");
		PROD_CATEGORY_MAP.put("33","ADD");
		PROD_CATEGORY_MAP.put("36","DIS");
		PROD_CATEGORY_MAP.put("37","DIS");
		PROD_CATEGORY_MAP.put("39","ADD");
	}
	
	public static RelationshipToSubscriber mapRelationship(String relationship) {
		LOG.debug("> mapRelationship");
		RelationshipToSubscriber rts;
		
		if (!StringUtils.hasText(relationship) ) {
			return RelationshipToSubscriber.UNKNOWN;
		}
		
		try {
			rts = RelationshipToSubscriber.fromValue(relationship);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			rts = RelationshipToSubscriber.UNKNOWN;
		}
		LOG.debug("< mapRelationship");
		return rts;
	}

	public static ProductCategory mapProduct(String categoryCode) {
		LOG.debug("> mapProduct");
		ProductCategory prodEnum;
		
		if (!StringUtils.hasText(categoryCode) ) {
			return ProductCategory.UNKNOWN;
		}
		
		try{
			prodEnum = ProductCategory.fromValue(categoryCode.toUpperCase());
		}catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			prodEnum = ProductCategory.UNKNOWN;
		}
		LOG.debug("< mapProduct");
		return prodEnum;
	}

	public static LocalBlueShieldPlanCode mapPlanCode(String planCode) {
		LOG.debug("> mapPlanCode");
		LocalBlueShieldPlanCode planCodeEnum = null;
		
		if (!StringUtils.hasText(planCode) ) {
			return planCodeEnum;
		}
		
		try {
			planCodeEnum = LocalBlueShieldPlanCode.fromValue(planCode);
		} catch (IllegalArgumentException e) {
			planCodeEnum = null;
		}
		LOG.debug("< mapPlanCode");
		return planCodeEnum;
	}

	public static EnrollmentSystemCode mapEnrollmentSystemCode(String payloadCode) {
		LOG.debug("> mapEnrollmentSystemCode");
		EnrollmentSystemCode msCode;
		
		if (!StringUtils.hasText(payloadCode) ) {
			return EnrollmentSystemCode.UNKNOWN;
		}
		
		try {
			msCode = EnrollmentSystemCode.fromValue(payloadCode);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			msCode = EnrollmentSystemCode.UNKNOWN;
		}
		LOG.debug("< mapEnrollmentSystemCode");
		return msCode;
	}

	public static Gender mapGender(String payrollGender) {
		LOG.debug("> mapGender");
		Gender gender;
		
		if (!StringUtils.hasText(payrollGender) ) {
			return Gender.UNKNOWN;
		}
		
		try {
			gender = Gender.fromValue(payrollGender);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			gender = Gender.UNKNOWN;
		}
		LOG.debug("< mapGender");
		return gender;
	}

	// enrollment code "064"?
	public static ASUIndicator mapAsu(final EnrollmentSystemCode enrollmentSystemCode, final String groupId) {
		LOG.debug("> mapAsu");
		ASUIndicator asu = null;

		if ((groupId != null && groupId.startsWith("99")) && enrollmentSystemCode == EnrollmentSystemCode.TRZ_FACETS) {
			asu = ASUIndicator.INDIVIDUAL;
		} else if ((groupId != null && groupId.startsWith("IRA")) && enrollmentSystemCode == EnrollmentSystemCode.TRZ_FACETS) {
			asu = ASUIndicator.GOVERNMENT;
		} else if ((groupId != null && groupId.equals("ND50")) && enrollmentSystemCode == EnrollmentSystemCode.TRZ_FACETS) {
			asu = ASUIndicator.GOVERNMENT;
		} else if ((groupId != null && groupId.equals("ITM4")) && enrollmentSystemCode == EnrollmentSystemCode.TRZ_FACETS) {
			asu = ASUIndicator.GOVERNMENT;
		} else if (enrollmentSystemCode == EnrollmentSystemCode.FEP_MD || enrollmentSystemCode == EnrollmentSystemCode.FEP_DC || enrollmentSystemCode == EnrollmentSystemCode.CFA) {
			asu = ASUIndicator.GOVERNMENT;
		} else if (enrollmentSystemCode == EnrollmentSystemCode.NASCO_MD) {
			asu = ASUIndicator.LARGE;
		} else if (enrollmentSystemCode == EnrollmentSystemCode.NASCO_DC) {
			asu = ASUIndicator.LARGE;
		} else if (enrollmentSystemCode == EnrollmentSystemCode.TMG) {
			asu = ASUIndicator.GOVERNMENT;
		} else if ((groupId != null && !groupId.startsWith("99")) && enrollmentSystemCode == EnrollmentSystemCode.TRZ_FACETS) {
			asu = ASUIndicator.SMALL_MEDIUM;
		}
		LOG.debug("< mapAsu");
		return asu;
	}

	// enrollment code "064"?
	public static String mapProtectedGroupType(String accountName, String accountId, String groupId, EnrollmentSystemCode enrollmentCode) {
		LOG.debug("> mapProtectedGroupType");
		if (groupId != null && groupId.startsWith("IRA")) {
			return "CONGRESSIONAL";
		} else if (groupId != null && groupId.equals("ND50")) {
			return "ND50";
		} else if (groupId != null && groupId.equals("1TM4")) {
			return "POTUS";
		} else if (enrollmentCode == EnrollmentSystemCode.FEP_MD) {
			return "FEP_MD";
		} else if (enrollmentCode == EnrollmentSystemCode.FEP_DC) {
			return "FEP_DC";
		} 
		else if ((accountId != null && accountId.equals("000000001000079")) || (accountName != null && accountName.contains("CAREFIRST"))) {
			return "HOUSE ACCOUNT";
		} else {
			return null;
		}
	}
	
	public static ASUIndicator groupAsu2MbrSearchAsu(String groupAsu){
		ASUIndicator mbrSearchAsu = null;
		
		if (!StringUtils.hasText(groupAsu) ) {
			return mbrSearchAsu;
		}
		
		try {
			mbrSearchAsu = ASUIndicator.fromValue(groupAsu);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
		}
		return mbrSearchAsu;
	}
	
	public static LegalEntity mapLegalEntity(String legalEntity) {
		LOG.debug("> mapLegalEntity");
		LegalEntity legalEntityEnum = null;
		if (!StringUtils.hasText(legalEntity) ) {
			return legalEntityEnum;
		}
		try {			
			legalEntityEnum = LegalEntity.fromValue(legalEntity);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			legalEntityEnum = null;
		}
		LOG.debug("< mapLegalEntity");
		return legalEntityEnum;
	}
	
	public static ClaimsSystemCode mapClaimSystemCode(String claimSystemCodeStr) {
		LOG.debug("> mapClaimSystemCode");
		ClaimsSystemCode claimSystemCode;
		try {
			claimSystemCode = ClaimsSystemCode.fromValue(claimSystemCodeStr);
		} catch (IllegalArgumentException e) {
			LOG.error(ILLEGAL_ARG_EXCEPTION, e);
			claimSystemCode = ClaimsSystemCode.UNKNOWN;
		}
		LOG.debug("< mapClaimSystemCode");
		return claimSystemCode;
	}

}
