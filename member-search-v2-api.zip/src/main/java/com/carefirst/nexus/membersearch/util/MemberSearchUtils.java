package com.carefirst.nexus.membersearch.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.membersearch.constants.ApplicationConstants;
import com.carefirst.nexus.membersearch.entity.MemberCoverage;
import com.carefirst.nexus.membersearch.entity.Product;
import com.carefirst.nexus.membersearch.gen.model.ASUIndicator;
import com.carefirst.nexus.membersearch.gen.model.AddressType;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.LegalEntity;
import com.carefirst.nexus.membersearch.gen.model.LocalBlueShieldPlanCode;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;
import com.github.jknack.handlebars.internal.lang3.ObjectUtils;

/**
 * Member Search util class.
 * @author author
 *
 */
public class MemberSearchUtils {
	
	private MemberSearchUtils() {}
	private static final Logger LOG = LogManager.getLogger(MemberSearchUtils.class);

	/**
	 * Method converts String to Date format.
	 * @param pattern pattern
	 * @param dateString dateString
	 * @return Date
	 */
	public static Date stringToDateConverter(String pattern, String dateString) {
		if (!StringUtils.hasText(pattern) || !StringUtils.hasText(dateString))
			return null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			formatter.setLenient(false);
			return formatter.parse(dateString);
		} catch (ParseException e) {
			LOG.error("Not able to parse date string {}", e.getMessage());

			AppJSONException jsonException = new AppJSONException(ErrorResponseCode.ERROR_VALIDATION_ERROR,
					new String[] { ApplicationConstants.PARSE_DATE_ERROR_MSG });
			jsonException.setStatus(HttpStatus.BAD_REQUEST);
			LOG.error("Primary element missing as part of search criteria {} ", jsonException.getMessage());
			throw jsonException;
		}
	}
	
	
	public static LocalDate stringToLocalDateConverter(String pattern, String dateString) {

		if (!StringUtils.hasText(pattern) || !StringUtils.hasText(dateString))
			return null;

		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
		return LocalDate.parse(dateString, dateTimeFormatter);

	}
	

	/**
	 * Product Category Mapper method.
	 * @param category category
	 * @return ProductCategory
	 */

	public static ProductCategory productCategoryMapper(String category) {
		ProductCategory prodEnum = null;
		if (StringUtils.hasText(category)) {
			switch (category.toUpperCase()) {
			case "MED":
				prodEnum = ProductCategory.MEDICAL;
				break;
			case "DEN":
				prodEnum = ProductCategory.DENTAL;
				break;
			case "VIS":
				prodEnum = ProductCategory.VISION;
				break;
			case "DRG":
				prodEnum = ProductCategory.DRUG;
				break;
			case "CAT":
				prodEnum = ProductCategory.CATASTROPHIC;
				break;
			case "WEL":
				prodEnum = ProductCategory.WELLNESS;
				break;
			case "DMM":
				prodEnum = ProductCategory.DISEASEMANAGEMENT;
				break;
			case "LIF":
				prodEnum = ProductCategory.LIFE;
				break;
			case "ADD":
				prodEnum = ProductCategory.ACCDEATHDISMEMB;
				break;
			case "DIS":
				prodEnum = ProductCategory.DISABILITY;
				break;		
			case "HRG":
				prodEnum = ProductCategory.HEARING;
				break;			
			case "UNK":
				prodEnum = ProductCategory.UNKNOWN;
				break;
			default:
				prodEnum = ProductCategory.UNKNOWN;
				break;
			}
		}
		return prodEnum;
	}
	
	
	/**
	 * Plan Code Mapper.
	 * @param products code
	 * @return LocalBlueShieldPlanCode
	 */
	@SuppressWarnings("null")
	public static LocalBlueShieldPlanCode planCodeMapper(List<Product> products) {
		LocalBlueShieldPlanCode planCodeEnum = null;
		String code = null;
		if(ObjectUtils.isNotEmpty(products) && !products.isEmpty()){
			code = products.get(0).getPlanCode();
		}
		if (StringUtils.hasText(code)) {
			switch (code) {
			case "690":
				planCodeEnum = LocalBlueShieldPlanCode.MD;
				break;
			case "580":
				planCodeEnum = LocalBlueShieldPlanCode.DC;
				break;
			default:
				break;
			}
		}
		return planCodeEnum;
	}

	/**
	 * Benefit Id Mapper.
	 * @param products
	 * @return String
	 */
	public static String benefitIdMapper(List<Product> products) {
		String benefitId = null;
		if(ObjectUtils.isNotEmpty(products) && !products.isEmpty()){
			benefitId = products.get(0).getBenefitId();
		}
		return benefitId;
	}

	/**
	 * Aca Mapper.
	 * @param products
	 * @return String
	 */
	public static boolean acaMapper(List<Product> products) {
		boolean aca = false;
		if(ObjectUtils.isNotEmpty(products) && !products.isEmpty()){
			aca = null!=products.get(0).getAca()?products.get(0).getAca():aca;
		}
		return aca;
	}

	/**
	 * Product Code Mapper.
	 * @param products
	 * @return String
	 */
	public static String productCodeMapper(List<Product> products) {
		String benefitId = null;
		if(ObjectUtils.isNotEmpty(products) && !products.isEmpty()){
			benefitId = products.get(0).getProductCode();
		}
		return benefitId;
	}
	
	
	/**
	 * Address Type Mapper.
	 * @param type type
	 * @return AddressType
	 */
	public static AddressType addressTypeMapper(String type) {
		AddressType typeEnum = null;
		if (StringUtils.hasText(type)) {
			switch (type.toUpperCase()) {
			case "01":
				typeEnum = AddressType.ALTERNATE;
				break;
			case "02":
				typeEnum = AddressType.CONTRACT;
				break;
			case "03":
				typeEnum = AddressType.MEMBER;
				break;
			case "05":
				typeEnum = AddressType.HOME;
				break;
			case "08":
				typeEnum = AddressType.WORK;
				break;
			case "09":
				typeEnum = AddressType.MAILING;
				break;
			case "10":
				typeEnum = AddressType.INVOICE;
				break;
			default:
				break;
			}
		}
		return typeEnum;
	}
	

	/**
	 * genderMapper method.
	 * @param gender gender
	 * @return gender
	 */
	public static Gender genderMapper(String gender) {
		Gender genderEnum = null;
		if (StringUtils.hasText(gender)) {
			switch (gender.toUpperCase()) {
			case "M":
				genderEnum = Gender.MALE;
				break;
			case "F":
				genderEnum = Gender.FEMALE;
				break;
			default:
				break;
			}
		}
		return genderEnum;
	}
	
	/**
	 * asuIndicatorMapper method.
	 * @param marketSegment marketSegment
	 * @return marketSegment
	 */
	
	public static ASUIndicator asuIndicatorMapper(String marketSegment) {
		ASUIndicator asuEnum = null;
		if (StringUtils.hasText(marketSegment)) {
			switch (marketSegment.toUpperCase()) {
			case "IND":
				asuEnum = ASUIndicator.INDIVIDUAL;
				break;
			case "SM":
				asuEnum = ASUIndicator.SMALL_MEDIUM;
				break;
			case "LG":
				asuEnum = ASUIndicator.LARGE;
				break;
			case "GOV":
				asuEnum = ASUIndicator.GOVERNMENT;
				break;
			default:
				break;
			}
		}
		return asuEnum;
	}
	
	/**
	 * egwpIndicatorMapper method.
	 * @param egwpInd value for member search DDS column name egwp_ind
	 * @return egwpInd
	 */
	
	public static boolean egwpIndicatorMapper(String egwpInd) {
		
		boolean isEGWPGroup = false;
		
		if(StringUtils.hasText(egwpInd) && ApplicationConstants.INDICATOR.Y.toString().equalsIgnoreCase(egwpInd)) {
			isEGWPGroup = true;
		}		

		return isEGWPGroup;
	}	
	

	/**
	 * relToSubscriberMapper method.
	 * @param relToSubscriber relToSubscriber
	 * @return RelationshipToSubscriber
	 */
	public static RelationshipToSubscriber relToSubscriberMapper(String relToSubscriber) {
		RelationshipToSubscriber relToSubscriberEnum = null;
		if (StringUtils.hasText(relToSubscriber)) {
			switch (relToSubscriber.toUpperCase()) {
			case "01":
				relToSubscriberEnum = RelationshipToSubscriber.SPOUSE;
				break;
			case "18":
				relToSubscriberEnum = RelationshipToSubscriber.SELF;
				break;
			case "19":
				relToSubscriberEnum = RelationshipToSubscriber.CHILD;
				break;
			case "21":
				relToSubscriberEnum = RelationshipToSubscriber.UNKNOWN;
				break;
			case "22":
				relToSubscriberEnum = RelationshipToSubscriber.HANDICAP_DEPENDENT;
				break;
			case "23":
				relToSubscriberEnum = RelationshipToSubscriber.SPONSORED_DEPENDENT;
				break;
			case "26":
				relToSubscriberEnum = RelationshipToSubscriber.GUARDIAN;
				break;
			case "34":
				relToSubscriberEnum = RelationshipToSubscriber.OTHER_ADULT;
				break;
			case "38":
				relToSubscriberEnum = RelationshipToSubscriber.COLLATERAL_DEPENDENT;
				break;
			case "39":
				relToSubscriberEnum = RelationshipToSubscriber.ORGAN_DONOR;
				break;
			case "40":
				relToSubscriberEnum = RelationshipToSubscriber.CADAVER_DONOR;
				break;
			case "53":
				relToSubscriberEnum = RelationshipToSubscriber.LIFE_PARTNER;
				break;
			case "G8":
				relToSubscriberEnum = RelationshipToSubscriber.OTHER_RELATIONSHIP;
				break;
			default:
				break;
			}
		}
		return relToSubscriberEnum;
	}
	

	/**
	 * enrollmentSystemCodeMapper method.
	 * @param enrollmentSystemCode enrollmentSystemCode
	 * @return EnrollmentSystemCode
	 */
	public static EnrollmentSystemCode enrollmentSystemCodeMapper(String enrollmentSystemCode) {
		EnrollmentSystemCode enrollmentSystemCodeEnum = null;
		if (StringUtils.hasText(enrollmentSystemCode)) {
			try {
				enrollmentSystemCodeEnum = EnrollmentSystemCode.fromValue(enrollmentSystemCode.toUpperCase());
			} catch (IllegalArgumentException e) {
				LOG.error("enrollmentSystemCodeMapper IllegalArgumentException occured");
				enrollmentSystemCodeEnum = null;
			}
		}
		return enrollmentSystemCodeEnum;
	}
	
	
	/**
	 * dateToStringConverter method
	 * @param pattern
	 * @param date
	 * @return
	 */
	public static String dateToStringConverter(String pattern, Date date) {
		if (!StringUtils.hasText(pattern) || date == null) {
			return null;
		}
		DateFormat formatter = new SimpleDateFormat(pattern);
		return formatter.format(date);
	}
	
	/**
	 * Set the default value null And below value to respective enum 
	 * CFMI= CFMI,03 
	 * BLUECHOICE= 02,BC 
	 * CAPITALCARE= CC 
	 * GHMSI= 01,GHMSI 
	 * FIRSTCARE= 13,FC
	 * CAREFIRSTADVANTAGE= A,14
	 * 
	 * @param legalEntityCode
	 * @return
	 */
	@SuppressWarnings("null")
	public static LegalEntity legalEntityMapper(List<Product> products) {
		LegalEntity legalEntityEnum = null;
		String legalEntityCode = null;
		if(ObjectUtils.isNotEmpty(products) && !products.isEmpty()){
			legalEntityCode = products.get(0).getLegalEntity();
		}
			
		if (StringUtils.hasText(legalEntityCode)) {
			switch (legalEntityCode.toUpperCase()) {
			case "CFMI":
				legalEntityEnum = LegalEntity.CFMI;
				break;
			case "BC":
				legalEntityEnum = LegalEntity.BLUECHOICE;
				break;
			case "03":
				legalEntityEnum = LegalEntity.CFMI;
				break;	
			case "02":
				legalEntityEnum = LegalEntity.BLUECHOICE;
				break;
			case "CC":
				legalEntityEnum = LegalEntity.CAPITALCARE;
				break;
			case "GHMSI","01":
				legalEntityEnum = LegalEntity.GHMSI;
				break;
			case "FC","13":
				legalEntityEnum = LegalEntity.FIRSTCARE;
				break;
			case "A":
				legalEntityEnum = LegalEntity.CAREFIRSTADVANTAGE;
				break;
			case "P":
				legalEntityEnum = LegalEntity.CAREFIRSTADVANTAGEPPO;
				break;
			case "14":
				legalEntityEnum = LegalEntity.CAREFIRSTADVANTAGE;
				break;	
			case "CHP":
				legalEntityEnum = LegalEntity.CareFirstCHPDC;
				break;
			case "CDSNP":
				legalEntityEnum = LegalEntity.CareFirstDualPrimeHMOSNP;
				break;
			case "CHPMD":
				legalEntityEnum = LegalEntity.CareFirstCommunityHealthPlanMaryland;
				break;				
			default:
				break;
			}
		}
		return legalEntityEnum;
	}
	
	public static List<String> generateGroupList(String accountId) {
		List<String> groupIdList = null;
		
		if (StringUtils.hasText(accountId)) {			
			String[] groupIdArray = accountId.split(ApplicationConstants.STRING_DOT);
			if (groupIdArray.length > 1) {
				groupIdList = (Arrays.asList(groupIdArray).stream().filter(part->!part.equals("0")
				&& !part.isEmpty()).toList());
			}		 
		}
		
		LOG.debug("Generated groupd list {} for the accountId {}", groupIdList, accountId);
		
		return groupIdList;
	}
	
	public static ClaimsSystemCode mapClaimsSystemCode(String code) {
		ClaimsSystemCode claimsSystemCode;
		try {
			claimsSystemCode = ClaimsSystemCode.fromValue(code);
		} catch (IllegalArgumentException e) {
			claimsSystemCode = null;
		}
		return claimsSystemCode;
	}

	/**
	 * @param startDate
	 * @param endDate
	 * @param memberCoverages
	 * @return
	 */
	public static List<MemberCoverage> filterCoveragesBasedOnDates(LocalDate startDate, LocalDate endDate,
			List<MemberCoverage> memberCoverages) {
		List<MemberCoverage> memberCovgs = new ArrayList<>();
		if (null != startDate || null != endDate) {
			for (MemberCoverage predicate : memberCoverages) {
				if (validateWithStartEndDates(startDate,endDate,predicate.getEnrollmentFromDate(),predicate.getEnrollmentThruDate()) 
						|| validateWithStartDate(startDate,endDate,predicate.getEnrollmentThruDate())
						|| validateWithEndDate(startDate,endDate,predicate.getEnrollmentFromDate())) {
					memberCovgs.add(predicate);
				}
			}
		} else {
			memberCovgs = memberCoverages;
		}
		return memberCovgs;
	}

	/**
	 * @param startDate
	 * @param endDate
	 * @param enrollmentFromDate
	 * @return
	 */
	private static boolean validateWithEndDate(LocalDate startDate,LocalDate endDate, LocalDate enrollmentFromDate){
		return startDate ==null && endDate !=null
		 && (enrollmentFromDate !=null && (enrollmentFromDate.isBefore(endDate) || enrollmentFromDate.isEqual(endDate)));
	}

	/**
	 * @param startDate
	 * @param endDate
	 * @param enrollmentThruDate
	 * @return
	 */
	private static boolean validateWithStartDate(LocalDate startDate,LocalDate endDate, LocalDate enrollmentThruDate){
		return startDate !=null && endDate ==null
		 && (enrollmentThruDate !=null && (enrollmentThruDate.isAfter(startDate) || enrollmentThruDate.isEqual(startDate)));
	}
	
	/**
	 * @param startDate
	 * @param endDate
	 * @param enrollmentFromDate
	 * @param enrollmentThruDate
	 * @return
	 */
	private static boolean validateWithStartEndDates(LocalDate startDate, LocalDate endDate,LocalDate enrollmentFromDate, LocalDate enrollmentThruDate){
		
		return startDate !=null && endDate !=null 
		&& ((enrollmentFromDate !=null && enrollmentFromDate.isAfter(startDate) && enrollmentFromDate.isBefore(endDate))
			|| (enrollmentThruDate !=null && enrollmentThruDate.isAfter(startDate) && enrollmentThruDate.isBefore(endDate))
			|| (enrollmentFromDate !=null && enrollmentThruDate !=null && (enrollmentFromDate.isBefore(startDate) || enrollmentFromDate.isEqual(startDate))
				&& (enrollmentThruDate.isAfter(startDate) || enrollmentThruDate.isEqual(startDate)))
			);
	}

}
