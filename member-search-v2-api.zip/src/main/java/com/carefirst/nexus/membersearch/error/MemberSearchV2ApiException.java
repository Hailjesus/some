package com.carefirst.nexus.membersearch.error;

/**
 * @author carefirst
 *
 */
public class MemberSearchV2ApiException extends Exception {

	private static final long serialVersionUID = 7488832108215025713L;

	public MemberSearchV2ApiException(String message){
		super(message);
	}
	
}
