package com.carefirst.nexus.membersearch.util;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.carefirst.nexus.utils.web.model.ErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class CustomAuthenticationFailureHandlerUtil implements AuthenticationEntryPoint {

	private static final Logger LOG = LogManager.getLogger(CustomAuthenticationFailureHandlerUtil.class);

	private ObjectMapper objectMapper;

	public CustomAuthenticationFailureHandlerUtil(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	@Override
	public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			AuthenticationException e) throws IOException {
		HttpStatus status = HttpStatus.FORBIDDEN; // 403 // HttpStatus is enum
		String userReadableMessage = "JWT Token Cannot Authenticate User";
		httpServletResponse.setStatus(status.value());
		ErrorResponse error = new ErrorResponse();
		error.setCode("401");
		error.setMessage("Unauthorized");
		error.setMoreInfo(userReadableMessage);
		/* serializes any java value as string */
		httpServletResponse.getOutputStream().println(objectMapper.writeValueAsString(error));
		LOG.error(e);
	}
}