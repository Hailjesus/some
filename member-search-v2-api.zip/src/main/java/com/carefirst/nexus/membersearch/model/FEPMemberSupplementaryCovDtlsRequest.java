package com.carefirst.nexus.membersearch.model;

import java.util.List;

import com.carefirst.nexus.fepmembercoverage.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.fepmembercoverage.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.fepmembercoverage.gen.model.SupplementaryDetailsRecordType;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FEPMemberSupplementaryCovDtlsRequest {

	private List<SupplementaryDetailsRecordType> recordType;
	private String subscriberId;
	private String memberLifeId;
	private List<String> groupIds;
	private List<SourceSystemMemberIdFilter> sourceSystemMemberIdFilter;
	private List<MemberSuffixFilter> memberSuffixFilter;
}
