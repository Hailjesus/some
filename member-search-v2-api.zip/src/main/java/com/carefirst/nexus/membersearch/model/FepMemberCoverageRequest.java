package com.carefirst.nexus.membersearch.model;

import java.time.LocalDate;
import java.util.List;

import com.carefirst.nexus.fepmembercoverage.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.fepmembercoverage.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.fepmembercoverage.gen.model.SourceSystemMemberIdFilter;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FepMemberCoverageRequest {

	private String subscriberId;
	private String memberLifeId;
	private LocalDate startDate;
	private LocalDate endDate;
	private List<String> groupIds;
	private List<EnrollmentSystemCode> enrollmentSystemCodes;
	private List<ClaimsSystemCode> claimsSystemCodes;
	private List<SourceSystemMemberIdFilter> sourceSystemMemberIdFilter;
	private List<MemberSuffixFilter> memberSuffixFilter;

}
