
package com.carefirst.nexus.membersearch.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@Getter
@Setter
public class CdhInfo {

    private Boolean fundAdmin;
    private Boolean integratedDeductible;
    private String type;
    private Boolean warehouseProductCode;
  
   
}
