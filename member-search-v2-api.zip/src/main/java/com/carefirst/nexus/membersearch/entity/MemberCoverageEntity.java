package com.carefirst.nexus.membersearch.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import com.querydsl.core.annotations.QueryInit;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
@Entity
@Table(name = "memb_cov", schema = "mbr_coverage")
public class MemberCoverageEntity {

	@SequenceGenerator(name = "trans_gen", sequenceName = "mbr_coverage.memb_cov_memb_cov_id_seq", allocationSize = 1)
	@GeneratedValue(generator = "trans_gen")
	@Id
	@Column(name = "memb_cov_id")
	private int membCovId;
	
	@Column(name = "srce_sys_memb_id")
    private String sourceSystemMemberId;
	
	@Column(name = "srce_sys_cd")
	private String enrollmentSystemCode;
	
	@Column(name = "subscriber_id")
	private String subscriberId;
	
	@Column(name = "group_id")
    private String groupId;
	
	@Column(name = "sub_grp_id")
    private String subGroupId;
	
	@Column(name = "cov_json", columnDefinition = "jsonb")
	@QueryInit("*")
	@JdbcTypeCode(SqlTypes.JSON)
	private MemberCoverageDetails memberDetails;
	@Column(name = "aud_insrt_id")
	protected String auditInsertId;

	@Column(name = "aud_insrt_tmstp")
	protected LocalDateTime auditInsertTimestamp;

	@Column(name = "aud_updt_id")
	protected String auditUpdateId;

	@Column(name = "aud_updt_tmstp")
	protected LocalDateTime auditUpdateTimestamp;
	
    public int getMembCovId() {
		return membCovId;
	}

	public void setMembCovId(int membCovId) {
		this.membCovId = membCovId;
	}
   
    public String getSourceSystemMemberId() {
        return sourceSystemMemberId;
    }

    public void setSourceSystemMemberId(String sourceSystemMemberId) {
        this.sourceSystemMemberId = sourceSystemMemberId;
    }

    public String getEnrollmentSystemCode() {
        return enrollmentSystemCode;
    }

    public void setEnrollmentSystemCode(String enrollmentSystemCode) {
        this.enrollmentSystemCode = enrollmentSystemCode;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getSubGroupId() {
        return subGroupId;
    }

    public void setSubGroupId(String subGroupId) {
        this.subGroupId = subGroupId;
    }

    public MemberCoverageDetails getMemberDetails() {
        return memberDetails;
    }

    public void setMemberDetails(MemberCoverageDetails memberDetails) {
        this.memberDetails = memberDetails;
    }

    public String getAuditInsertId() {
		return auditInsertId;
	}

	public void setAuditInsertId(String auditInsertId) {
		this.auditInsertId = auditInsertId;
	}

	public LocalDateTime getAuditInsertTimestamp() {
		return auditInsertTimestamp;
	}

	public void setAuditInsertTimestamp(LocalDateTime auditInsertTimestamp) {
		this.auditInsertTimestamp = auditInsertTimestamp;
	}

	public String getAuditUpdateId() {
		return auditUpdateId;
	}

	public void setAuditUpdateId(String auditUpdateId) {
		this.auditUpdateId = auditUpdateId;
	}

	public LocalDateTime getAuditUpdateTimestamp() {
		return auditUpdateTimestamp;
	}

	public void setAuditUpdateTimestamp(LocalDateTime auditUpdateTimestamp) {
		this.auditUpdateTimestamp = auditUpdateTimestamp;
	}
}