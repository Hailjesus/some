
package com.carefirst.nexus.membersearch.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.Valid;

// import com.carefirst.nexus.gen.model.CoverageLevel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@Getter
@Setter
public class MemberCoverage {

    private String sid;
    private String lid;
    private String deptNumber;
    private String productCategory;
    private String productLineCode;
    private String packageClassId;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate enrollmentFromDate;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate enrollmentThruDate;
    
    private String memberPrefix;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate originalEffectiveDate;
    
    private String claimsSystemCode;
    private String medicalAuthSystem;
    private String mentalHealthAuthSystem;
    private String relationshipToSubscriber;
    private String memberHICN;
    private Boolean asoOptOutInd;
    private Boolean tcciCswInd;
    private Boolean aca;
    private String wellnessPrimacyInd;
    private String wellnessVendorName;
    private String wellnessVendorIndividualId;
    private String levelOfCoverageCode;
    private Boolean cftrStyleBeneInd;
    private String termStatus;
    private String termStatusReasonCode;
    private String memberTermReasonCode;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@JsonDeserialize(using= LocalDateDeserializer.class) 
	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate memberTermProcessedDate;
    
    private String sourceCoverageLevel;
    private String memberStatusCode;
    private String benefitsPackageIdentifier;
    private String benefitsRenewalMonth;
    private Boolean coreVision;
    private String classDesc;
    
    //Derived Attributes in Kafka
    private Boolean aptcInd;
    private String lidExtension;
    private String trueNascoSuffix;
    private Boolean adultVision;
    private Boolean embeddedCoverage;
    private Boolean pediatric;
    private Boolean flexLink;
    private Boolean dvb;
    private Boolean prospectMember;
    private PlanElectedUnits dvbPlanElectedUnits;
    private RenewalPolicy benefitRenewalPolicy;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
   	@JsonDeserialize(using= LocalDateDeserializer.class) 
   	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate delinquencyDate;
    private Boolean delinquentInd;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
   	@JsonDeserialize(using= LocalDateDeserializer.class) 
   	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate gracePeriodStatusDate;
    private String gracePeriodStatusInd;
    private Boolean voidedForBinderNonPayment;
    
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
   	@JsonDeserialize(using= LocalDateDeserializer.class) 
   	@JsonSerialize(using= LocalDateSerializer.class) 
    private LocalDate voidedForBinderNonPaymentDate;
   
    @Valid
    private List<Product> product = null;
    
    /** Real Time Derived*/
    private String nascoMbrSexRelCd;
    //private CoverageLevel coverageLevel;
   // private BenefitPlanPeriod benefitPlanPeriod;
    

	/*@Override
	public String toString() {
		return "MemberCoverage [aptcInd=" + aptcInd + ", lidExtension=" + lidExtension + ", trueNascoSuffix="
				+ trueNascoSuffix + ", adultVision=" + adultVision + ", embeddedCoverage=" + embeddedCoverage
				+ ", flexLink=" + flexLink + ", dvb=" + dvb
				+ ", prospectMember=" + prospectMember + ", delinquencyDate=" + delinquencyDate + ", delinquentInd="
				+ delinquentInd + ", gracePeriodStatusDate=" + gracePeriodStatusDate + ", gracePeriodStatusInd="
				+ gracePeriodStatusInd + ", voidedForBinderNonPayment=" + voidedForBinderNonPayment
				+ ", voidedForBinderNonPaymentDate=" + voidedForBinderNonPaymentDate + ", product=" + product + "]";
	}*/
   
    
}
