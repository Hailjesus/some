package com.carefirst.nexus.membersearch.model;

import groovy.transform.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ProtectGroupTypeDataResponse {
	
	private String groupId;
	private String protectedGroupType;

}
