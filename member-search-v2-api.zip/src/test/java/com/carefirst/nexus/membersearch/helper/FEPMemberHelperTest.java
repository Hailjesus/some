package com.carefirst.nexus.membersearch.helper;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.formula.functions.T;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.fepmembercoverage.gen.model.AddressType;
import com.carefirst.nexus.fepmembercoverage.gen.model.CoverageStatus;
import com.carefirst.nexus.fepmembercoverage.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.fepmembercoverage.gen.model.Gender;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberAddress;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberEnrollmentDetails;
import com.carefirst.nexus.fepmembercoverage.gen.model.Product;
import com.carefirst.nexus.fepmembercoverage.gen.model.ProductCategory;
import com.carefirst.nexus.fepmembercoverage.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberDescriptor;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FEPMemberHelperTest {

    @InjectMocks
    FEPMemberHelper febMemberHelper;

    @Test
    public void testFilterFEPMembers() {
        List<Member> ddsMembersList = new ArrayList<>();
        Member member = new Member();
        ddsMembersList.add(member);
        member.setClaimsSystemCode(ClaimsSystemCode.FEP);
        assertNotNull(febMemberHelper.filterFEPMembers(ddsMembersList));

    }

    @Test
    public void filterNonFEPMembers() {
        List<Member> ddsMembersList = new ArrayList<>();
        Member member = new Member();
        ddsMembersList.add(member);
        member.setClaimsSystemCode(ClaimsSystemCode.CFA);
        assertNotNull(febMemberHelper.filterNonFEPMembers(ddsMembersList));

    }

    @Test
    public void filterNonFEPMembers_null() {
        List<Member> ddsMembersList = new ArrayList<>();
        Member member = new Member();
        ddsMembersList.add(member);
        assertNotNull(febMemberHelper.filterNonFEPMembers(ddsMembersList));

    }

    @Test
    public void extractSubscriberIdTest() {
        assertNotNull(febMemberHelper.extractSubscriberId("R123456789", "T060R1234567801"));
    }

    @Test
    public void extractSubscriberId_T064Test() {
        assertNotNull(febMemberHelper.extractSubscriberId("R123456789", "T064R1234567801"));
    }

    @Test
    public void extractSubscriberId_SubscriberId() {
        assertNotNull(febMemberHelper.extractSubscriberId("R12345678", "T064R1234567801"));
    }

    @Test
    public void getDistinctSubscriberIdSuffix() {
        List<Member> ddsMembersList = new ArrayList<>();
        Member member = new Member();
        MemberDescriptor memberDescriptor = new MemberDescriptor();
        memberDescriptor.setMemberSuffix("01");
        memberDescriptor.setSubscriberId("12345567");
        memberDescriptor.setMemberLifeId("1234566");
        member.setMemberDescriptor(memberDescriptor);
        ddsMembersList.add(member);
        assertNotNull(febMemberHelper.getDistinctSubscriberIdSuffix(ddsMembersList));
    }

    @Test
    public void getDistinctSubscriberIdSuffixNull() {
        List<Member> ddsMembersList = new ArrayList<>();
        Member member = new Member();
        MemberDescriptor memberDescriptor = new MemberDescriptor();
        memberDescriptor.setSubscriberId("12345567");
        memberDescriptor.setMemberLifeId("1234566");
        member.setMemberDescriptor(memberDescriptor);
        ddsMembersList.add(member);
        assertNotNull(febMemberHelper.getDistinctSubscriberIdSuffix(ddsMembersList));
    }

    @Test
    public void addAllNullTest() {
        List<T> finalList = new ArrayList<>();
        List<T> elements = new ArrayList<>();
        assertNotNull(febMemberHelper.addAll(finalList, elements));
    }

    @Test
    public void addAllTest() {
        List<T> finalList = new ArrayList<>();
        List<T> elements = new ArrayList<>();
        T t = new T();
        T t1 = new T();
        elements.add(t);
        elements.add(t1);
        assertNotNull(febMemberHelper.addAll(finalList, elements));
    }

    @Test
    public void transformCoverageTypeToMemberSearchList() {
        List<MemberCoverage> fepCoveragesList = new ArrayList<>();
        MemberCoverage memberCoverage = new MemberCoverage();
        List<MemberAddress> addressDetails = new ArrayList<>();
        com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor covMemberDescriptor = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
        com.carefirst.nexus.fepmembercoverage.gen.model.MemberEnrollmentDetails memberEnrollmentDetails=new com.carefirst.nexus.fepmembercoverage.gen.model.MemberEnrollmentDetails();
        memberEnrollmentDetails.setClaimsSystemCode(com.carefirst.nexus.fepmembercoverage.gen.model.ClaimsSystemCode.CFA);
        CoverageStatus coverageStatus=new CoverageStatus();
        coverageStatus.setEffectiveDate(LocalDate.of(2012, 9, 12));
        coverageStatus.setTerminationDate(LocalDate.of(2012, 9, 12));
        memberEnrollmentDetails.setCoverageStatus(coverageStatus);
        List<Product> products=new ArrayList<Product>();
        Product product=new Product();
        product.setAca(true);
        product.setProductCode("test");
        products.add(product);
        memberEnrollmentDetails.setProductCategory(ProductCategory.ACCDEATHDISMEMB);
        memberEnrollmentDetails.setProduct(products);
        covMemberDescriptor.setAlternateId("1234");
        covMemberDescriptor.setSourceSystemMemberId("12345");
        covMemberDescriptor.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        covMemberDescriptor.setSubscriberId("12331233");
        covMemberDescriptor.setLegacyId("1234566");
        covMemberDescriptor.setDateofBirth(LocalDate.of(1999, 9, 8));
        com.carefirst.nexus.fepmembercoverage.gen.model.Name name = new com.carefirst.nexus.fepmembercoverage.gen.model.Name();
        name.setFirstName("tesr");
        name.setLastName("ieshhh");
        name.setMiddleName("tegyeg");
        name.setPrefix("ewrte");
        name.setSuffix("hdgjfhgsd");
        covMemberDescriptor.setName(name);
        covMemberDescriptor.setGender(Gender.MALE);
        covMemberDescriptor.setRelationshipToSubscriber(RelationshipToSubscriber.SELF);
        covMemberDescriptor.setMemberLifeId("325wet");
        covMemberDescriptor.setMemberSSN("rwetrwrte");
        covMemberDescriptor.setMemberSuffix("01");
        covMemberDescriptor.setGroupId("trhyaef");
        covMemberDescriptor.setProtectedGroupType("refdf");
        covMemberDescriptor.setPublicSubscriberIdPrefix("sfGD");
        covMemberDescriptor.setPublicSubscriberId("hxcgfhgfh");
        covMemberDescriptor.setPublicSubscriberIdType("xchghf");
        covMemberDescriptor.setSubscriberEmployerId("123445");
        memberCoverage.setMemberDescriptor(covMemberDescriptor);
        memberCoverage.setMemberEnrollmentDetails(memberEnrollmentDetails);
        MemberAddress memberAddress=new MemberAddress();
        com.carefirst.nexus.fepmembercoverage.gen.model.Address  membAddress=new com.carefirst.nexus.fepmembercoverage.gen.model.Address();
        memberAddress.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        membAddress.setState("dsfdfgh");
        membAddress.setCountry("India");
        membAddress.setZipCode("3456677");
        membAddress.setCity("HYD");
       membAddress.setLine2("test");
       membAddress.setLine3("123345");
       membAddress.setPrimaryAddressIndicator(true);
       membAddress.setAddressType(AddressType.ALTERNATE);
       membAddress.setAddressTypeDescription("chchfggf");
       membAddress.setZipCode("test");
       membAddress.setZipFourCode("tesr");
       addressDetails.add(memberAddress);
       memberCoverage.setAddressDetails(addressDetails);
        fepCoveragesList.add(memberCoverage);
        assertNotNull(febMemberHelper.transformCoverageTypeToMemberSearchList(fepCoveragesList));
    }

    @Test
    public void transformCoverageTypeToMemberSearchListEmpty() {
        List<MemberCoverage> fepCoveragesList = new ArrayList<>();
        MemberCoverage memberCoverage = new MemberCoverage();
        com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor md = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
                memberCoverage.setMemberDescriptor(md);
                MemberEnrollmentDetails med = new MemberEnrollmentDetails();
                memberCoverage.setMemberEnrollmentDetails(med);
        fepCoveragesList.add(memberCoverage);
        assertNotNull(febMemberHelper.transformCoverageTypeToMemberSearchList(fepCoveragesList));
    }
}
