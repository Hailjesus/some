package com.carefirst.nexus.membersearch.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.carefirst.nexus.datadict.impl.DataDictionaryServiceImpl;
import com.carefirst.nexus.group.gen.api.GroupAccountDetailsApi;
import com.carefirst.nexus.group.gen.model.GroupAccount;
import com.carefirst.nexus.group.gen.model.GroupAccountSearchResponse;
import com.carefirst.nexus.utils.DateUtils;
import com.carefirst.nexus.utils.web.error.AppJSONException;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MemberDerivedDataServiceTest {

	MemberDerivedDataService mddService;
	
	@Mock
	GroupAccountDetailsApi groupAccountDetailsApi;
	@Mock
	DataDictionaryServiceImpl dataDictionaryService;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		mddService = new MemberDerivedDataService(groupAccountDetailsApi, dataDictionaryService);
	}

	@Test
	public void testFetchProtectedGroupType_returns_NOT_AVAILABLE_whenBlank() {
		final String expectedPGT = "NOT_AVAILABLE";
		String actualPGT = mddService.fetchProtectedGroupType(null);
		assertEquals(expectedPGT, actualPGT);
	}
	
	@Test
	public void testFetchPtrGrpType(){
		String groupId = "PROTECTEDGROUP";
		when(dataDictionaryService.getSingleMappedValue("CAREFIRST", "PROTECTED_GROUP", "CAREFIRST",
				"PROTECTED_GROUP_TYPE", groupId.substring(0, 9), DateUtils.getCurrentDate())).thenReturn("GroupType");
		assertEquals("GroupType", mddService.fetchProtectedGroupType(groupId));
	}

	@Test
	public void testFetchAccountDetails() {
		String groupId = "99D1234";
		GroupAccountSearchResponse response = new GroupAccountSearchResponse();
		response.setAccounts(new ArrayList<GroupAccount>());
		when(groupAccountDetailsApi.getAccounts(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(mddService.fetchGroupAccountDetails(groupId));
	}
	

	@Test
	public void testfetchProtectedGroupTypeDetails(){
		String groupId = "PROTECTEDGROUP";
		when(dataDictionaryService.getSingleMappedValue("CAREFIRST", "PROTECTED_GROUP", "CAREFIRST",
				"PROTECTED_GROUP_TYPE", groupId.substring(0, 9), DateUtils.getCurrentDate())).thenReturn("GroupType");
		Set<String> request = new HashSet<>();
        request.add("99D1234");
		assertNotNull(mddService.fetchProtectedGroupTypeDetails(request));
	}
	
	@Test
	public void testfetchGroupAccountDetails(){
		String groupId = "99D123456";
		when(dataDictionaryService.getSingleMappedValue("CAREFIRST", "PROTECTED_GROUP", "CAREFIRST",
				"PROTECTED_GROUP_TYPE", groupId.substring(0, 9), DateUtils.getCurrentDate())).thenReturn("GroupType");
		assertNotNull(mddService.fetchGroupAccountDetails(groupId));
	}

	@Test
    public void testfetchGroupAccountDetailsException(){
        try{
			String groupId = "99D123456";
            when(groupAccountDetailsApi
					.getAccounts(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
            .thenThrow(new WebClientResponseException(401, "test", null,null,null));
            mddService.fetchGroupAccountDetails(groupId);
        }catch(AppJSONException e){
            assertNotNull(e);
        }
    }

}
