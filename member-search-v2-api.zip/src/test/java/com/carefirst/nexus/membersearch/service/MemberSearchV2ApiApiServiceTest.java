package com.carefirst.nexus.membersearch.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.carefirst.nexus.group.gen.model.GroupAccount;
import com.carefirst.nexus.group.gen.model.GroupAssociation;
import com.carefirst.nexus.membersearch.entity.MemberCoverage;
import com.carefirst.nexus.membersearch.entity.MemberCoverageDetails;
import com.carefirst.nexus.membersearch.entity.MemberCoverageEntity;
import com.carefirst.nexus.membersearch.entity.Product;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Gender;
import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberResponse;
import com.carefirst.nexus.membersearch.gen.model.ProductCategory;
import com.carefirst.nexus.membersearch.gen.model.RelationshipToSubscriber;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.membersearch.helper.MemberSearchHelper;
import com.carefirst.nexus.membersearch.model.MemberSearchV2ApiModel;
import com.carefirst.nexus.membersearch.repository.MemberCoverageEntityManager;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MemberSearchV2ApiApiServiceTest {

    @InjectMocks
    MemberSearchV2ApiApiService memberSearchV2ApiApiService;
    @Mock
    MemberCoverageEntityManager memberCoverageEntityManager;
    @Mock
    MemberDerivedDataService memberDerivedDataService;
    @Mock
    MemberSearchHelper memberSearchHelper;
    @Mock
    FEPMemberEligibilityService fepMemberEligibilityService;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        List<String> listOfRestrictedLifeIds=Arrays.asList("997769","997769");
        ReflectionTestUtils.setField(memberSearchV2ApiApiService, "listOfRestrictedLifeIds", listOfRestrictedLifeIds);
    }

   @Test
    public void findMembersTest(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        mbrCoverageEntities.add(memberCoverageEntity);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         
         LocalDate dateofBirth=LocalDate.of(1975,04,9);
         ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
         "12345677", "test",
          "test", dateofBirth, Gender.FEMALE, 
          RelationshipToSubscriber.SELF, "null", "null", "null", 
          "null", null, null, null, null, null, null, null, null, null,
           null, null, null,
           null, null, null, null, null);
           assertNotNull(response);

    }

    @Test
    public void findMembersTestwithMemberLifeId(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        mbrCoverageEntities.add(memberCoverageEntity);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         LocalDate dateofBirth=LocalDate.of(1975,04,9);
         ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
         "12345677", "test",
          "test", dateofBirth, Gender.FEMALE, 
          RelationshipToSubscriber.SELF, "null", "null", "null", 
          "null", null, null, null, null, null, null, null, null, null,
           null, null, null,
           null, null, null, null, null);
           assertNotNull(response);

    }

    @Test
    public void findMembersTestwithMemberLifeIdCD(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        mbrCoverageEntities.add(memberCoverageEntity);
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         LocalDate dateofBirth=LocalDate.of(1975,04,9);
         ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
         "12345677", "test",
          "test", dateofBirth, Gender.FEMALE, 
          RelationshipToSubscriber.SELF, "null", "null", "null", 
          "null", null, null, null, null, null, "CD.432.456", null, null, null,
           null, null, null,
           null, null, null, null, null);
           assertNotNull(response);

    }

    @Test
    public void findMembersTestwithMemberLifeIdMAPD(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        mbrCoverageEntities.add(memberCoverageEntity);
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         LocalDate dateofBirth=LocalDate.of(1975,04,9);
         ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
         "12345677", "test",
          "test", dateofBirth, Gender.FEMALE, 
          RelationshipToSubscriber.SELF, "null", "null", "null", 
          "null", null, null, null, null, null, "MAPD.432.456", null, null, null,
           null, null, null,
           null, null, null, null, null);
           assertNotNull(response);

    }

    @Test
    public void findMembersTestwithMemberLifeIdRestrictedException(){
         
            AppJSONException exception = assertThrows(AppJSONException.class, ()->{
                memberSearchV2ApiApiService.findMembers("997769", null, 
                null, null,
                 null, null, null, 
                 RelationshipToSubscriber.SELF, "null", "null", "null", 
                 "null", null, null, null, null, null, null, null, null, null,
                  null, null, null,
                  null, null, null, null, null);
        });
        assertEquals(ErrorResponseCode.ERROR_VALIDATION_ERROR, exception.getCode());
    }

    @Test
    public void findMembersTestwithMemberLifeIdCDGroups(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
        mbrCoverageEntities.add(memberCoverageEntity);
        List<GroupAccount> groupAccounts = new ArrayList<>();
        GroupAccount grpAcct = new GroupAccount();
        grpAcct.setAccountId("CD123.432.456");
        List<GroupAssociation> grpAssoList = new ArrayList<>();
        GroupAssociation grpAsso = new GroupAssociation();
        grpAsso.setGroupId("21SY");
        grpAsso.setGroupAssociationStartDate(LocalDate.of(1975,04,9));
        grpAsso.setGroupAssociationEndDate(LocalDate.of(1975,04,9));
        grpAssoList.add(grpAsso);
        grpAcct.setGroupAssociations(grpAssoList);
        groupAccounts.add(grpAcct);
        LocalDate dateofBirth=LocalDate.of(1975,04,9);
        List<String> groupIds = new ArrayList<>();
        groupIds.add("21SY");
        groupIds.add("51XY");
        when(memberDerivedDataService.fetchGroupAccountDetails(Mockito.any()))
        .thenReturn(groupAccounts);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
        ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
        "12345677", "test",
        "test", dateofBirth, Gender.FEMALE, 
        RelationshipToSubscriber.SELF, "null", "null", "null", 
        "null", null, null, null, groupIds, null, "432456", null, null, null,
        null, null, null,
        null, null, null, null, null);
        assertNotNull(response);

    }

    @Test
    public void findMembersTestwithuseFemsForFep(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        List<Member> mbrCoverage = new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
        mbrCoverageEntities.add(memberCoverageEntity);
        List<GroupAccount> groupAccounts = new ArrayList<>();
        GroupAccount grpAcct = new GroupAccount();
        grpAcct.setAccountId("CD123.432.456");
        List<GroupAssociation> grpAssoList = new ArrayList<>();
        GroupAssociation grpAsso = new GroupAssociation();
        grpAsso.setGroupId("21SY");
        grpAsso.setGroupAssociationStartDate(LocalDate.of(1975,04,9));
        grpAsso.setGroupAssociationEndDate(LocalDate.of(1975,04,9));
        grpAssoList.add(grpAsso);
        grpAcct.setGroupAssociations(grpAssoList);
        groupAccounts.add(grpAcct);
        LocalDate dateofBirth=LocalDate.of(1975,04,9);
        List<String> groupIds = new ArrayList<>();
        groupIds.add("21SY");
        groupIds.add("51XY");
        when(memberDerivedDataService.fetchGroupAccountDetails(Mockito.any()))
        .thenReturn(groupAccounts);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         when(fepMemberEligibilityService.checkAndUpdateFepMemberData(
            Mockito.any(),
            Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mbrCoverage);
        ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
        "12345677", "test",
        "test", dateofBirth, Gender.FEMALE, 
        RelationshipToSubscriber.SELF, "null", "null", "null", 
        "null", null, null, null, groupIds, null, "432.456", null, null, null,
        null, null, null,
        null, null, null, null, true);
        assertNotNull(response);

    }

    @Test
    public void findMembersTestwithuseFemsForFepFalse(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        List<Member> mbrCoverage = new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("");
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
        mbrCoverageEntities.add(memberCoverageEntity);
        List<GroupAccount> groupAccounts = new ArrayList<>();
        GroupAccount grpAcct = new GroupAccount();
        grpAcct.setAccountId("CD123.432.456");
        List<GroupAssociation> grpAssoList = new ArrayList<>();
        GroupAssociation grpAsso = new GroupAssociation();
        grpAsso.setGroupId("21SY");
        grpAsso.setGroupAssociationStartDate(LocalDate.of(1975,04,9));
        grpAsso.setGroupAssociationEndDate(LocalDate.of(1975,04,9));
        grpAssoList.add(grpAsso);
        grpAcct.setGroupAssociations(grpAssoList);
        groupAccounts.add(grpAcct);
        LocalDate dateofBirth=LocalDate.of(1975,04,9);
        List<String> groupIds = new ArrayList<>();
        groupIds.add("21SY");
        groupIds.add("51XY");
        when(memberDerivedDataService.fetchGroupAccountDetails(Mockito.any()))
        .thenReturn(groupAccounts);
         when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.mock(MemberSearchV2ApiModel.class)))
         .thenReturn(mbrCoverageEntities);
         when(fepMemberEligibilityService.checkAndUpdateFepMemberData(
            Mockito.any(),
            Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(mbrCoverage);
        List<GroupFilter> groupFilters = new ArrayList<>();
        GroupFilter grpFilter = new GroupFilter();
        grpFilter.setGroupId("21SY");
        grpFilter.setGroupAssoicationStartDate("1988-01-01");
        grpFilter.setGroupAssoicationEndDate("2025-01-01");
        groupFilters.add(grpFilter);
        ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
        "12345677", "test",
        "test", dateofBirth, Gender.FEMALE, 
        RelationshipToSubscriber.SELF, "null", "null", "null", 
        "null", null, null, null, groupIds, groupFilters, "432.456", null, null, null,
        null, null, null,
        null, null, null, null, false);
        assertNotNull(response);

    }

    @Test
    public void findMembersTestwithException(){
        try{
            when(memberDerivedDataService.fetchGroupAccountDetails(Mockito.any()))
            .thenThrow(new WebClientResponseException(401, "test", null,null,null));
            memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
            "12345677", "test",
            "test", null, Gender.FEMALE, 
            RelationshipToSubscriber.SELF, "null", "null", "null", 
            "null", null, null, null, null, null, "CD.432.456", null, null, null,
            null, null, null,
            null, null, null, null, null);
        }catch(AppJSONException e){
            assertNotNull(e);
        }
    }

    @Test
    public void TestisRestrictedMemberLifeId(){
            assertFalse(memberSearchV2ApiApiService.isRestrictedMemberLifeId(null));
    }

    @Test
    public void findMembersTestwithAccountId(){
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("21SY");
        MemberCoverageDetails md = new MemberCoverageDetails();
        List<MemberCoverage> memCovs = new ArrayList<>();
        MemberCoverage memCov = new MemberCoverage();
        memCov.setEnrollmentFromDate(LocalDate.of(1975,04,9));
        memCov.setEnrollmentThruDate(LocalDate.of(1975,04,9));
        List<Product> products = new ArrayList<>();
        Product product = new Product();
        product.setPlanCode("test");
        product.setBenefitId("test");
        product.setAca(true);
        products.add(product);
        memCov.setProduct(products);
        memCov.setProductCategory("test");
        memCovs.add(memCov);
        md.setMemberCoverages(memCovs);
        memberCoverageEntity.setMemberDetails(md);
        mbrCoverageEntities.add(memberCoverageEntity);
        MemberCoverageEntity memberCoverageEntity1=new MemberCoverageEntity();
        memberCoverageEntity1.setAuditInsertId("123");
        memberCoverageEntity1.setGroupId("21SY");
        MemberCoverageDetails md1 = new MemberCoverageDetails();
        List<MemberCoverage> memCovs1 = new ArrayList<>();
        MemberCoverage memCov1 = new MemberCoverage();
        memCov1.setEnrollmentFromDate(LocalDate.of(1975,04,9));
        memCov1.setEnrollmentThruDate(LocalDate.of(1975,04,9));
        List<Product> products1 = new ArrayList<>();
        Product product1 = new Product();
        product1.setPlanCode("test");
        product1.setBenefitId("test");
        product1.setAca(true);
        products1.add(product1);
        memCov1.setProduct(products1);
        memCovs1.add(memCov1);
        md1.setMemberCoverages(memCovs1);
        memberCoverageEntity1.setMemberDetails(md1);
        mbrCoverageEntities.add(memberCoverageEntity1);
        List<GroupAccount> groupAccounts = new ArrayList<>();
        GroupAccount grpAcct = new GroupAccount();
        grpAcct.setAccountId("CD123.432.456");
        List<GroupAssociation> grpAssoList = new ArrayList<>();
        GroupAssociation grpAsso = new GroupAssociation();
        grpAsso.setGroupId("21SY");
        grpAsso.setGroupAssociationStartDate(LocalDate.of(1975,04,9));
        grpAsso.setGroupAssociationEndDate(LocalDate.of(1975,04,9));
        grpAssoList.add(grpAsso);
        grpAcct.setGroupAssociations(grpAssoList);
        groupAccounts.add(grpAcct);
        LocalDate dateofBirth=LocalDate.of(1975,04,9);
        List<String> groupIds = new ArrayList<>();
        groupIds.add("21SY");
        groupIds.add("51XY");
        when(memberDerivedDataService.fetchGroupAccountDetails(Mockito.any()))
        .thenReturn(groupAccounts);
        when(memberCoverageEntityManager.getMemberCoverageEntities(Mockito.any()))
        .thenReturn(mbrCoverageEntities);
        ResponseEntity<MemberResponse> response=memberSearchV2ApiApiService.findMembers("1234557", "1234566", 
        "12345677", "test",
        "test", dateofBirth, Gender.FEMALE, 
        RelationshipToSubscriber.SELF, "null", "null", "null", 
        "null", null, null, null, groupIds, null, "CD123.432.456", null, null, null,
        null, null, null,
        null, null, null, null, null);
        assertNotNull(response);

    }

    @Test
    public void TestfilterCoverageEntities(){
        List<MemberCoverageEntity> memberCoverageEntities = new ArrayList<>();
        MemberCoverageEntity mce = new MemberCoverageEntity();
        mce.setEnrollmentSystemCode("055");
        mce.setSourceSystemMemberId("171");
        mce.setSubGroupId("21SY");
        MemberCoverageDetails memDetails = new MemberCoverageDetails();
        List<MemberCoverage> memCovs = new ArrayList<>();
        MemberCoverage memCov = new MemberCoverage();
        memCov.setProductCategory("DEN");
        memCov.setClaimsSystemCode("022");
        memCov.setEnrollmentFromDate(LocalDate.of(1975,04,9));
        memCov.setEnrollmentThruDate(LocalDate.of(1975,04,9));
        memCovs.add(memCov);
        memDetails.setMemberCoverages(memCovs);
        mce.setMemberDetails(memDetails);
        memberCoverageEntities.add(mce);
        MemberSearchV2ApiModel memberSearchRequest = new MemberSearchV2ApiModel();
        List<ClaimsSystemCode> cscList = new ArrayList<>();
        cscList.add(ClaimsSystemCode.CFA);
        memberSearchRequest.setClaimsSystemCodes(cscList);
        List<SourceSystemMemberIdFilter> ssmfList = new ArrayList<>();
        SourceSystemMemberIdFilter ssmf = new SourceSystemMemberIdFilter();
        ssmf.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        ssmf.setSourceSystemMemberId("171");
        ssmfList.add(ssmf);
        memberSearchRequest.setSourceSystemMemberIdFilter(ssmfList);
        memberSearchRequest.setSubGroupIds(Arrays.asList("21SY"));
        memberSearchRequest.setExtendSubgroupIdsMatchToDeptNumber(true);
        List<ProductCategory> productCatList = new ArrayList<>();
        productCatList.add(ProductCategory.DENTAL);
        memberSearchRequest.setProductCategories(productCatList);
        memberSearchRequest.setStartDate(LocalDate.of(1975,04,9));
        memberSearchRequest.setEndDate(LocalDate.of(1975,04,9));
        assertNotNull(memberSearchV2ApiApiService.filterCoverageEntities(memberCoverageEntities,memberSearchRequest));
    }

}
