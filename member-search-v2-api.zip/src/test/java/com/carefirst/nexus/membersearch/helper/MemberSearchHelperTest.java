package com.carefirst.nexus.membersearch.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.group.gen.model.Group;
import com.carefirst.nexus.group.gen.model.GroupAccount;
import com.carefirst.nexus.group.gen.model.GroupAssociation;
import com.carefirst.nexus.membersearch.entity.MemberCoverage;
import com.carefirst.nexus.membersearch.entity.MemberCoverageDetails;
import com.carefirst.nexus.membersearch.entity.MemberCoverageEntity;
import com.carefirst.nexus.membersearch.entity.Name;
import com.carefirst.nexus.membersearch.entity.Product;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.GroupFilter;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberDescriptor;
import com.carefirst.nexus.membersearch.gen.model.SourceSystemMemberIdFilter;
import com.carefirst.nexus.membersearch.model.MemberSearchV2ApiModel;
import com.carefirst.nexus.membersearch.model.ProtectGroupTypeDataResponse;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MemberSearchHelperTest {

    @InjectMocks
    MemberSearchHelper memberSearchHelper;

    @Test
    public void testConvertToModelObject(){
        LocalDate dateOfBirth=LocalDate.of(1975,04,9);
        List<MemberCoverageEntity> memberCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        MemberCoverageDetails memberDetails=new MemberCoverageDetails();
        List<MemberCoverage> memberCoverages=new ArrayList<MemberCoverage>();
        List<Product> products=new  ArrayList<Product>();
        Product product=new Product();
        product.setPlanCode("test");
        product.setBenefitId("0123");
        product.setAca(false);
        products.add(product);
        MemberCoverage memberCoverage=new MemberCoverage();
        memberCoverage.setAca(true);
        memberCoverage.setMedicalAuthSystem("test");
        memberCoverage.setProductCategory("test");
        memberCoverage.setProduct(products);
        memberCoverage.setDeptNumber("test1");
        memberCoverage.setMemberPrefix("01");
        memberCoverage.setEnrollmentFromDate(dateOfBirth);
        memberCoverage.setEnrollmentThruDate(dateOfBirth);
        memberCoverage.setPackageClassId("12344");
        memberCoverage.setClaimsSystemCode("test");
        memberCoverages.add(memberCoverage);
        memberDetails.setMemberCoverages(memberCoverages);
        memberDetails.setAlternateId("1234567");
        memberDetails.setControlPlanCode("123");
        memberDetails.setDateOfBirth(dateOfBirth);
        memberDetails.setGender("M");
        memberDetails.setMemberLifeId("12345556");
        memberDetails.setMemberSSN("qwertt");
        memberDetails.setRelationshipToSubscriber("134");
        Name name=new Name();
        name.setFirstName("tesr");
        name.setLastName("ieshhh");
        name.setMiddleName("tegyeg");
        memberDetails.setName(name);
        memberCoverageEntity.setMemberDetails(memberDetails);

        memberCoverageEntity.setEnrollmentSystemCode("CAF");
        memberCoverageEntity.setSubGroupId("tets");
        memberCoverageEntity.setSubGroupId("234566");
        memberCoverageEntity.setSourceSystemMemberId("234rsee");
        memberCoverageEntities.add(memberCoverageEntity);
      assertNotNull(MemberSearchHelper.convertToModelObject(memberCoverageEntities));
    }

    @Test
    public void testGetUniqueMbrgroupdetails(){
        List<Member> mbrCoverages=new ArrayList<Member>();
        Member member=new Member();
        MemberDescriptor memberDescriptor=new MemberDescriptor();
        memberDescriptor.setMemberLifeId("1234");
        memberDescriptor.setSubscriberId("123456");
        memberDescriptor.setGroupId("2345");
        memberDescriptor.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        member.setSubGroupId("test");
        member.setMemberDescriptor(memberDescriptor);
        member.setTerminationDate(LocalDate.of(2019,8,9));
        member.setEffectiveDate(LocalDate.of(2019, 3, 13));
        mbrCoverages.add(member);
        Member member1=new Member();
        MemberDescriptor memberDescriptor1=new MemberDescriptor();
        memberDescriptor1.setMemberLifeId("12341213");
        memberDescriptor1.setSubscriberId("123456");
        memberDescriptor1.setGroupId("2345133");
        memberDescriptor1.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        member1.setSubGroupId("test123");
        member1.setMemberDescriptor(memberDescriptor1);
        member1.setTerminationDate(LocalDate.of(2019,8,9));
        member1.setEffectiveDate(LocalDate.of(2019, 3, 13));
        mbrCoverages.add(member1);
        assertNotNull(MemberSearchHelper.getUniqueMbrgroupdetails(mbrCoverages));
    }
    
    @Test
    public void validationExceptionTest()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        
        AppJSONException exception = assertThrows(AppJSONException.class, ()->{
            MemberSearchHelper.validation(memberSearchRequest);
        });
        assertEquals(ErrorResponseCode.ERROR_VALIDATION_ERROR, exception.getCode());
    }

    @Test
    public void validationTest()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setAccountId("test");
        memberSearchRequest.setDateOfBirth(LocalDate.of(2019,8,9));
        memberSearchRequest.setLastName("Test");
        memberSearchRequest.setMemberLifeId("Test");
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void validationTest_SubscriberId()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setAccountId("test");
        memberSearchRequest.setDateOfBirth(LocalDate.of(2019,8,9));
        memberSearchRequest.setLastName("Test");
        memberSearchRequest.setSubscriberId("test");
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void validationTest_MemberSSN()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setAccountId("test");
        memberSearchRequest.setDateOfBirth(LocalDate.of(2019,8,9));
        memberSearchRequest.setLastName("Test");
        memberSearchRequest.setMemberSSN("test");
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void validationTest_SourceSystemMemberIdFilter()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setAccountId("test");
        memberSearchRequest.setDateOfBirth(LocalDate.of(2019,8,9));
        memberSearchRequest.setLastName("Test");
        List<SourceSystemMemberIdFilter> ssif = new ArrayList<>();
        memberSearchRequest.setSourceSystemMemberIdFilter(ssif);
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void validationTest_firstLastName()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setAccountId("test");
        memberSearchRequest.setLastName("Test");
        memberSearchRequest.setFirstName("Test");
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void validationTest_firstNameDob()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setMemberLifeId("test");
        memberSearchRequest.setDateOfBirth(LocalDate.of(2019,8,9));
        memberSearchRequest.setFirstName("Test");
        MemberSearchHelper.validation(memberSearchRequest);
        assertTrue(true);
    }

    @Test
    public void testgetUniqueMbrgroupdetails()
    {
        List<Member> mbrCoverages=new ArrayList<Member>();
        Member member=new Member();
        Member member1=new Member();
        Member member2=new Member();
        MemberDescriptor memberDescriptor=new MemberDescriptor();
        memberDescriptor.setMemberLifeId("123443423");
        memberDescriptor.setSubscriberId("123456");
        memberDescriptor.setGroupId("2345");
        memberDescriptor.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        MemberDescriptor memberDescriptor1=new MemberDescriptor();
        memberDescriptor1.setMemberLifeId("1234567");
        memberDescriptor1.setSubscriberId("1234567");
        memberDescriptor1.setGroupId("2345");
        memberDescriptor1.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        MemberDescriptor memberDescriptor2=new MemberDescriptor();
        memberDescriptor2.setMemberLifeId("123456");
        memberDescriptor2.setSubscriberId("1234567");
        memberDescriptor2.setGroupId("23456");
        memberDescriptor2.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        member.setSubGroupId("test");
        member.setMemberDescriptor(memberDescriptor);
        member.setTerminationDate(LocalDate.of(2018,8,9));
        member.setEffectiveDate(LocalDate.of(2030, 3, 13));
        member1.setSubGroupId("test");
        member1.setMemberDescriptor(memberDescriptor1);
        member1.setTerminationDate(LocalDate.of(2020,8,9));
        member1.setEffectiveDate(LocalDate.of(2028, 3, 13));
        member2.setSubGroupId("test2");
        member2.setTerminationDate(LocalDate.of(2017,8,9));
        member2.setEffectiveDate(LocalDate.of(2027, 3, 13));
        member2.setMemberDescriptor(memberDescriptor2);
        mbrCoverages.add(member);
        mbrCoverages.add(member1);
        mbrCoverages.add(member2);
        assertNotNull(MemberSearchHelper.getUniqueMbrgroupdetails(mbrCoverages));
    }

    @Test
    public void ssnValidationExceptionTest()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setPartialMatchMemberSSNEndsWith(true);
        memberSearchRequest.setMemberSSN("test");
        AppJSONException exception = assertThrows(AppJSONException.class, ()->{
            MemberSearchHelper.ssnValidation(memberSearchRequest);
        });
        assertEquals(ErrorResponseCode.ERROR_VALIDATION_ERROR, exception.getCode());
    }

    @Test
    public void ssnValidationMemberLifeIdTest()
    {
        MemberSearchV2ApiModel memberSearchRequest=new MemberSearchV2ApiModel();
        memberSearchRequest.setPartialMatchMemberSSNEndsWith(true);
        memberSearchRequest.setMemberSSN("test");
        memberSearchRequest.setMemberLifeId("test");
        assertTrue(MemberSearchHelper.ssnValidation(memberSearchRequest));
    }

    @Test
    public void testmapMemberSearchAccountinfo()
    {
        List<Member> mbrCoverages=new ArrayList<Member>();
        Member member=new Member();
        MemberDescriptor memberDescriptor=new MemberDescriptor();
        memberDescriptor.setMemberLifeId("1234");
        memberDescriptor.setSubscriberId("123456");
        memberDescriptor.setGroupId("1234");
        memberDescriptor.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        member.setSubGroupId("test");
        member.setMemberDescriptor(memberDescriptor);
        member.setTerminationDate(LocalDate.of(2019,8,9));
        member.setEffectiveDate(LocalDate.of(2019, 3, 13));
        mbrCoverages.add(member);
        List<Group> groups = new ArrayList<>();
        Set<String> memAccountDDSet = new HashSet<>();
        Group grp = new Group();
        grp.setGroupId("99D1234");
        grp.setConsumerDirect(true);
        groups.add(grp);
        memAccountDDSet.add("99D1234");
        List<ProtectGroupTypeDataResponse> protectGroupTypeList = new ArrayList<>();
        ProtectGroupTypeDataResponse maddres = new ProtectGroupTypeDataResponse();
        maddres.setGroupId("99D1234");
        maddres.setProtectedGroupType("test");
        protectGroupTypeList.add(maddres);
        MemberSearchHelper.mapMemberSearchAccountinfo(mbrCoverages,protectGroupTypeList);
        assertTrue(true);
    }

    @Test
    public void testmapMemberSearchAccountinfoSame()
    {
        List<Member> mbrCoverages=new ArrayList<Member>();
        Member member=new Member();
        MemberDescriptor memberDescriptor=new MemberDescriptor();
        memberDescriptor.setMemberLifeId("1234");
        memberDescriptor.setSubscriberId("123456");
        memberDescriptor.setGroupId("99D1234");
        memberDescriptor.setEnrollmentSystemCode(EnrollmentSystemCode.CFA);
        member.setSubGroupId("test");
        member.setMemberDescriptor(memberDescriptor);
        member.setTerminationDate(LocalDate.of(2019,8,9));
        member.setEffectiveDate(LocalDate.of(2019, 3, 13));
        mbrCoverages.add(member);
        List<Group> groups = new ArrayList<>();
        Set<String> memAccountDDSet = new HashSet<>();
        List<GroupAssociation> gas = new ArrayList<>();
        GroupAssociation grpa = new GroupAssociation();
        grpa.setGroupAssociationStartDate(LocalDate.of(2019,8,9));
        grpa.setGroupAssociationEndDate(LocalDate.of(2019,8,9));
        grpa.setGroupId("99D1234");
        gas.add(grpa);
        Group grp = new Group();
        grp.setGroupId("99D1234");
        grp.setConsumerDirect(true);
        grp.setEgwpGroup(false);
        grp.setGroupEffectiveDate(LocalDate.of(2019,8,9));
        grp.setGroupTerminationDate(LocalDate.of(2019,8,9));
        groups.add(grp);
        memAccountDDSet.add("99D1234");
        List<ProtectGroupTypeDataResponse> protectGroupTypeList = new ArrayList<>();
        ProtectGroupTypeDataResponse maddres = new ProtectGroupTypeDataResponse();
        maddres.setGroupId("99D1234");
        maddres.setProtectedGroupType("test");
        protectGroupTypeList.add(maddres);
        MemberSearchHelper.mapMemberSearchAccountinfo(mbrCoverages, protectGroupTypeList);
        assertTrue(true);
    }

    @Test
    public void testapplyGroupfilterCoverageEntities()
    {
        List<MemberCoverageEntity> mbrCoverageEntities=new ArrayList<>();
        MemberCoverageEntity memberCoverageEntity=new MemberCoverageEntity();
        memberCoverageEntity.setAuditInsertId("123");
        memberCoverageEntity.setGroupId("21SY");
        MemberCoverageDetails md = new MemberCoverageDetails();
        memberCoverageEntity.setMemberDetails(md);
        mbrCoverageEntities.add(memberCoverageEntity);
        List<GroupFilter> groupFilter = new ArrayList<>();
        GroupFilter grpFilter = new GroupFilter();
        grpFilter.setGroupId("21SY");
        grpFilter.setGroupAssoicationStartDate("2019-01-01");
        grpFilter.setGroupAssoicationEndDate("2024-01-01");
        groupFilter.add(grpFilter);
        assertNotNull(MemberSearchHelper.applyGroupfilterCoverageEntities(mbrCoverageEntities, groupFilter));
    }
}