package com.carefirst.nexus.membersearch.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.carefirst.nexus.fepmembercoverage.gen.api.FepmemberCoverageApi;
import com.carefirst.nexus.fepmembercoverage.gen.model.FepMemberCoveragesResponse;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.fepmembercoverage.gen.model.MemberSuffixFilter;
import com.carefirst.nexus.fepmembercoverage.gen.model.SupplementaryFepCoverageDetailsResponse;
import com.carefirst.nexus.membersearch.gen.model.ClaimsSystemCode;
import com.carefirst.nexus.membersearch.gen.model.EnrollmentSystemCode;
import com.carefirst.nexus.membersearch.gen.model.Member;
import com.carefirst.nexus.membersearch.gen.model.MemberDescriptor;
import com.carefirst.nexus.membersearch.model.FEPMemberSupplementaryCovDtlsRequest;
import com.carefirst.nexus.membersearch.model.FepMemberCoverageRequest;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.Silent.class)
public class FEPMemberEligibilityServiceTest {

	FEPMemberEligibilityService fepMemberEligibilityService;
	
	@Mock
	FepmemberCoverageApi fepmemberCoverageApi;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		fepMemberEligibilityService = new FEPMemberEligibilityService(fepmemberCoverageApi);
	}

	@Test
	public void testcheckAndUpdateFepMemberData() {
		List<Member> ddsMembers = new ArrayList<>();
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters = new ArrayList<>();
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		response.setMemberCoverages(new ArrayList<>());
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.checkAndUpdateFepMemberData(ddsMembers,inputSubscriberId,inputMemberLifeId,inputMbrSuffixFilters));
	}

	@Test
	public void testcheckAndUpdateFepMemberDataWithDDSMembers() {
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		List<Member> ddsMembers = new ArrayList<>();
		Member member = new Member();
		MemberDescriptor memdesc = new MemberDescriptor();
		memdesc.memberLifeId(inputMemberLifeId);
		memdesc.subscriberId(inputSubscriberId);
		member.setMemberDescriptor(memdesc);
		ddsMembers.add(member);
		List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters = new ArrayList<>();
		com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter msf = new com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter();
		msf.setMemberSuffix("FEP_MD");
		msf.setMemberSuffix("NASCO_MD");
		msf.setMemberSuffix("TRZ_FACETS");
		msf.setMemberSuffix("WEL");
		inputMbrSuffixFilters.add(msf);
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		List<MemberCoverage> memCovList = new ArrayList<>();
		MemberCoverage memCov = new MemberCoverage();
		com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor memdesc1 = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
		memdesc1.memberLifeId(inputMemberLifeId);
		memdesc1.subscriberId(inputSubscriberId);
		memCov.setMemberDescriptor(memdesc1);
		memCovList.add(memCov);
		response.setMemberCoverages(memCovList);
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.checkAndUpdateFepMemberData(ddsMembers,inputSubscriberId,inputMemberLifeId,inputMbrSuffixFilters));
	}

	@Test
	public void testCheckAndUpdateFepMemberDataWithDDSMembersValue() {
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		List<Member> ddsMembers = new ArrayList<>();
		Member member = new Member();
		MemberDescriptor memdesc = new MemberDescriptor();
		memdesc.memberLifeId(inputMemberLifeId);
		memdesc.subscriberId(inputSubscriberId);
		memdesc.setMemberSuffix("inputMemberLifeId");
		member.setMemberDescriptor(memdesc);
		member.setClaimsSystemCode(ClaimsSystemCode.fromValue("237"));
		ddsMembers.add(member);
		List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters = new ArrayList<>();
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		List<MemberCoverage> memCovList = new ArrayList<>();
		MemberCoverage memCov = new MemberCoverage();
		com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor memdesc1 = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
		memdesc1.memberLifeId(inputMemberLifeId);
		memdesc1.subscriberId(inputSubscriberId);
		memCov.setMemberDescriptor(memdesc1);
		memCovList.add(memCov);
		response.setMemberCoverages(memCovList);
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.checkAndUpdateFepMemberData(ddsMembers,inputSubscriberId,inputMemberLifeId,inputMbrSuffixFilters));
	}

	@Test
	public void testCheckAndUpdateFepMemberDataWithNonFepMembers() {
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		List<Member> ddsMembers = new ArrayList<>();
		Member member = new Member();
		MemberDescriptor memdesc = new MemberDescriptor();
		memdesc.memberLifeId(inputMemberLifeId);
		memdesc.subscriberId(inputSubscriberId);
		memdesc.setMemberSuffix("inputMemberLifeId");
		member.setMemberDescriptor(memdesc);
		member.setClaimsSystemCode(ClaimsSystemCode.fromValue("184"));
		ddsMembers.add(member);
		List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters = new ArrayList<>();
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		List<MemberCoverage> memCovList = new ArrayList<>();
		MemberCoverage memCov = new MemberCoverage();
		com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor memdesc1 = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
		memdesc1.memberLifeId(inputMemberLifeId);
		memdesc1.subscriberId(inputSubscriberId);
		memCov.setMemberDescriptor(memdesc1);
		memCovList.add(memCov);
		response.setMemberCoverages(memCovList);
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.checkAndUpdateFepMemberData(ddsMembers,inputSubscriberId,inputMemberLifeId,inputMbrSuffixFilters));
	}

	@Test
	public void testCheckAndUpdateFepMemberDataWithEmptyinputMemberLifeId() {
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		List<Member> ddsMembers = new ArrayList<>();
		Member member = new Member();
		MemberDescriptor memdesc = new MemberDescriptor();
		memdesc.memberLifeId(inputMemberLifeId);
		memdesc.subscriberId(inputSubscriberId);
		memdesc.setMemberSuffix("inputMemberLifeId");
		member.setMemberDescriptor(memdesc);
		member.setClaimsSystemCode(ClaimsSystemCode.fromValue("184"));
		ddsMembers.add(member);
		List<com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter> inputMbrSuffixFilters = new ArrayList<>();
		com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter inputMbrSuffixFilter = new com.carefirst.nexus.membersearch.gen.model.MemberSuffixFilter();
		inputMbrSuffixFilter.setEnrollmentSystemCode(EnrollmentSystemCode.FAC);
		inputMbrSuffixFilters.add(inputMbrSuffixFilter);
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		List<MemberCoverage> memCovList = new ArrayList<>();
		MemberCoverage memCov = new MemberCoverage();
		com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor memdesc1 = new com.carefirst.nexus.fepmembercoverage.gen.model.MemberDescriptor();
		memdesc1.memberLifeId(inputMemberLifeId);
		memdesc1.subscriberId(inputSubscriberId);
		memCov.setMemberDescriptor(memdesc1);
		memCovList.add(memCov);
		response.setMemberCoverages(memCovList);
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.checkAndUpdateFepMemberData(ddsMembers,inputSubscriberId,null,inputMbrSuffixFilters));
	}

	@Test
	public void testgetFepMemberCoverages() {
		List<MemberSuffixFilter> memberSuffixFilters = new ArrayList<>();
		MemberSuffixFilter memberSuffixFilter = new MemberSuffixFilter();
		memberSuffixFilter.setEnrollmentSystemCode(com.carefirst.nexus.fepmembercoverage.gen.model.EnrollmentSystemCode.FEP_DC);
		memberSuffixFilters.add(memberSuffixFilter);
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		response.setMemberCoverages(new ArrayList<>());
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.getFepMemberCoverages(inputSubscriberId,inputMemberLifeId,memberSuffixFilters));
	}
	@Test
	public void testgetFepMemberCoveragesNull() {
		List<MemberSuffixFilter> memberSuffixFilter = new ArrayList<>();
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		FepMemberCoveragesResponse response = new FepMemberCoveragesResponse();
		response.setMemberCoverages(new ArrayList<>());
		assertNotNull(fepMemberEligibilityService.getFepMemberCoverages(inputSubscriberId,inputMemberLifeId,memberSuffixFilter));
	}

	@Test
	public void testgetSupplementaryFEPCoverageDetails() {
		FEPMemberSupplementaryCovDtlsRequest request = new FEPMemberSupplementaryCovDtlsRequest();
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		request.setMemberLifeId(inputMemberLifeId);
		request.setSubscriberId(inputSubscriberId);
		SupplementaryFepCoverageDetailsResponse response = new SupplementaryFepCoverageDetailsResponse();
		response.setSupplementaryCoverageDetails(new HashMap());
		when(fepmemberCoverageApi
		.getSupplementaryFEPCoverageDetails(Mockito.any(), Mockito.any(),
		Mockito.any(), Mockito.any(), Mockito.any(),
		Mockito.any())).thenReturn(Mono.just(response));
		assertNotNull(fepMemberEligibilityService.getSupplementaryFEPCoverageDetails(request));
	}

	@Test
	public void testgetSupplementaryFEPCoverageDetailsException() {
		FEPMemberSupplementaryCovDtlsRequest request = new FEPMemberSupplementaryCovDtlsRequest();
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		request.setMemberLifeId(inputMemberLifeId);
		request.setSubscriberId(inputSubscriberId);
		assertTrue(true);
		when(fepmemberCoverageApi
		.getSupplementaryFEPCoverageDetails(Mockito.any(), Mockito.any(),
		Mockito.any(), Mockito.any(), Mockito.any(),
		Mockito.any())).thenThrow(new WebClientResponseException(401, "test", null,null,null) );
		fepMemberEligibilityService.getSupplementaryFEPCoverageDetails(request);
	}

	@Test
	public void testfindFepMemberCoveragesException() {
		FepMemberCoverageRequest request = new FepMemberCoverageRequest();
		String inputSubscriberId = "R1234567801";
		String inputMemberLifeId = "T060R1234567801";
		request.setMemberLifeId(inputMemberLifeId);
		request.setSubscriberId(inputSubscriberId);
		assertTrue(true);
		when(fepmemberCoverageApi.getFEPMemberCoverages(
			Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any(), Mockito.any(),
			Mockito.any(), Mockito.any())).thenThrow(new WebClientResponseException(401, "test", null,null,null) );
		fepMemberEligibilityService.findFepMemberCoverages(request);
	}
	

}
