
package com.carefirst.nexus.membersearch;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MemberSearchV2ApiApplicationTest {
    @Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
    }
    @Test
    public void healthCheck() {
    	MemberSearchV2ApiApplication app = new MemberSearchV2ApiApplication();
        try{
        	app.main(null);
            assertTrue(true);
        }catch(Exception e){        	
        }
    }
    
}